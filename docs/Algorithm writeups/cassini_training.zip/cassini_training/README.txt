Prerequisites:
- Python 3.x (there is a small chance that it might work on Python 2.x, but it was only tested with Python 3.4)
- Numpy (tested with version 1.8.1)
- Pandas (tested with version 0.14.1)
- scikit-learn (tested with version 0.15.1)

Training instructions:
- compile the pass 1 binary, by compiling with -DTRAINING_PASS=1
- pass it the full set of training images: this generates 'pass1_field_flat4.h'
- compile the pass 2 binary, by compiling with -DTRAINING_PASS=2
- pass it the full set of training images: this generates a directory named 'processed'
- execute pass2.py: this generates 'pass2_all_kernels.h' and 'pass2_forest.h'
- compile the pass 3 binary, by compiling with -DTRAINING_PASS=3
- pass it the full set of training images: this generates a file named 'pass3_input.csv'
- execute pass3.py: this generates 'pass3_adjuster.h'

