#include <cmath>
#include <stdexcept>
#include <iostream>

#include <bits/stdc++.h>
#include <sys/time.h>
//#include <emmintrin.h>
#include <sys/stat.h>

#ifndef TRAINING_PASS
#define TRAINING_PASS 0
#endif

#define VC          vector
#define VI          VC<int>
#define VF          VC<float>

int training_pass = TRAINING_PASS;
template<class T> T sqr(T x) { return x * x; }
const double P_NO_ORBIT = 0.15;
const double P_COMMON_BASKET = 0.05;
const int COMMON_BASKET = 1;
const int EDGE_BASKET = 2;
const int ORBIT_BASKET = 3;
const double DUPLICATE_PROBABILITY = 0.008;
const double SIGMA_R_PIXEL = 3.0;
const double SIGMA_L_PIXEL = 40.0;
const double SIGMA_L_PICTURE = 0.005;
const double ORBIT_PRIOR_L_ERROR = 2.5;
const double GRAVITATIONAL_MU = 37931187 * sqr(1.00248);
const int THREADS_NO = 1;
using namespace std;
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef int8_t i8;
typedef int16_t i16;
typedef int32_t i32;
template<class T> void print(vector < T > v) {cerr << "[";if (v.size()) cerr << v[0];for(int i=(1);i<(v.size());++i) cerr << ", " << v[i];cerr << "]" << endl;}
template<class T> string str(T x) {ostringstream o; o << x; return o.str();}
vector<string> nonempty_split(string s, char c = ' ') {vector<string> all; int p = 0, np; while (np = s.find(c, p), np >= 0) {if (np != p) all.push_back(s.substr(p, np - p)); p = np + 1;} if (p < s.size()) all.push_back(s.substr(p)); return all;}
vector<string> full_split(string s, char c = ' ') {vector<string> all; int p = 0, np; while (np = s.find(c, p), np >= 0) {all.push_back(s.substr(p, np - p)); p = np + 1;} if (s.size() > 0) all.push_back(s.substr(p)); return all;}
static inline void assert_invariant(bool condition) {
    if (!condition)
 throw std::logic_error("assert_invariant failed");
}
static inline void _range_check(bool condition, const char *message) {
    if (!condition)
 throw std::out_of_range((string)"range_check("+message+") failed");
}
template<class T>
T destructive_median(vector<T>& row, T deflt = 0) {
    if (row.size()) {
        std::nth_element(&row[0], &row[(row.size()-1)/2], &row[row.size()]);
        return 0.5 * (row[(row.size()-1)/2] + *std::min_element(&row[row.size()/2], &row[row.size()]));
    } else {
        return deflt;
    }
}
template<class T>
T sum(const vector<T>& array) {
 T s = 0;
 for (int i=0; i<array.size(); i++)
  s += array[i];
 return s;
}
template<class T>
T dot(const vector<T>& array, const vector<T>& array2) {
 _range_check(array.size() == array2.size(), "array.S == array2.S");
 T s = 0;
 for (int i=0; i<array.size(); i++)
  s += array[i] * array2[i];
 return s;
}
template<class T>
T mean(const vector<T>& array) {
 return sum(array) / array.size();
}
template<class T>
T weighted_mean(const vector<T>& array, const vector<T>& weight) {
 return dot(array, weight) / sum(weight);
}
double getTime() {
 timeval tv;
 gettimeofday(&tv, NULL);
 return tv.tv_sec + tv.tv_usec * 1e-6;
}
float sqr(float x) { return x*x; }
double sqr(double x) { return x*x; }
float fast_invsqrt(float x) {
    union {
        float f;
        uint32_t i;
    } u;
    u.f = x;
    u.i = 0x5f3759df - u.i/2;
    float y = u.f;
    return y * (1.5f - 0.5f * x * y * y);
}
typedef std::out_of_range TransformException;
template<int n,int p>
struct Mat {
 double data[n*p];
 Mat() {
  for (int k=0; k<n*p; k++)
   data[k] = 0;
 }
 template<typename... T>
 explicit Mat(T... data): data{data...} {}
 Mat<n,p> operator+(const Mat<n,p>& b) const {
  const Mat<n,p>& a = *this;
  Mat<n,p> r;
  for (int i=0; i<n; i++) for (int j=0; j<p; j++)
   r.at(i,j) = a.at(i,j) + b.at(i,j);
  return r;
 }
 Mat<n,p> operator-(const Mat<n,p>& b) const {
  const Mat<n,p>& a = *this;
  Mat<n,p> r;
  for (int i=0; i<n; i++) for (int j=0; j<p; j++)
   r.at(i,j) = a.at(i,j) - b.at(i,j);
  return r;
 }
 Mat<n,p>& operator+=(const Mat<n,p>& b) {
  Mat<n,p>& a = *this;
  for (int i=0; i<n; i++) for (int j=0; j<p; j++)
   a.at(i,j) += b.at(i,j);
  return a;
 }
 Mat<n,p>& operator-=(const Mat<n,p>& b) {
  Mat<n,p>& a = *this;
  for (int i=0; i<n; i++) for (int j=0; j<p; j++)
   a.at(i,j) -= b.at(i,j);
  return a;
 }
 template<int q>
 Mat<n,q> operator*(const Mat<p,q>& b) const {
  const Mat<n,p>& a = *this;
  Mat<n,q> r;
  for (int i=0; i<n; i++) for (int j=0; j<q; j++) {
   double sum = 0;
   for (int k = 0; k < p; k++)
    sum += a.at(i,k) * b.at(k,j);
   r.at(i,j) = sum;
  }
  return r;
 }
 Mat<n,p> operator*(double k) const {
  const Mat<n,p>& a = *this;
  Mat<n,p> r;
  for (int i=0; i<n; i++) for (int j=0; j<p; j++)
   r.at(i,j) = a.at(i,j) * k;
  return r;
 }
 Mat<p,n> transpose() const {
  const Mat<n,p>& a = *this;
  Mat<p,n> r;
  for (int i=0; i<p; i++) for (int j=0; j<n; j++)
   r.at(i,j) = a.at(j,i);
  return r;
 }
 double& at(int i, int j) {
  _range_check(0<=i && i<n, "0<=i && i<n");
  _range_check(0<=j && j<p, "0<=j && j<p");
  return data[i*p + j];
 }
 double at(int i, int j) const {
  _range_check(0<=i && i<n, "0<=i && i<n");
  _range_check(0<=j && j<p, "0<=j && j<p");
  return data[i*p + j];
 }
 double& at(int i) {
  static_assert(p==1, "Column vector only");
  _range_check(0<=i && i<n, "0<=i && i<n");
  return data[i*p + 0];
 }
 double at(int i) const {
  static_assert(p==1, "Column vector only");
  _range_check(0<=i && i<n, "0<=i && i<n");
  return data[i*p + 0];
 }
 double sqr_norm() const {
  static_assert(p==1, "Column vector only");
  double s = 0;
  for (int i=0; i<n; i++)
   s += sqr(at(i));
  return s;
 }
 double norm() const {
  return sqrt(sqr_norm());
 }
 Mat<p,1> row(int i) const {
  Mat<p,1> r;
  for (int i2=0; i2<n; i2++)
   r.at(i2) = at(i, i2);
  return r;
 }
 Mat<n,1> col(int j) const {
  Mat<n,1> r;
  for (int i2=0; i2<n; i2++)
   r.at(i2) = at(i2, j);
  return r;
 }
 int nRows() const { return n; }
 int nCols() const { return p; }
 template<int q>
 Mat<n,q> dot(const Mat<p,q>& b) const {
  const Mat<n,p>& a = *this;
  return a * b;
 }
};
typedef Mat<2,1> Vec2;
typedef Mat<3,1> Vec3;
typedef Mat<3,3> Mat3;
template<class Stream, int n>
Stream& operator<<(Stream& stream, Mat<n,1> m) {
 for (int i=0; i<n; i++)
  stream << (i ? ", " : "[") << m.at(i);
 return stream << "]";
}
template<class Stream>
Stream& operator<<(Stream& stream, Mat3 m) {
 for (int i=0; i<m.nRows(); i++)
  stream << (i ? ",\n" : "") << m.row(i);
 return stream;
}
template<class Stream, class T>
Stream& operator<<(Stream& stream, vector<T> m) {
    for (int i=0; i<m.size(); i++)
  stream << (i ? ", " : "[") << m.at(i);
    return stream << "]";
}
const double PI = 3.1415926535897932384626433832795;
static const double DEG_TO_RAD = PI/180;
static const double RAD_TO_DEG = 180/PI;
static const double SATURN_RIGHT_ASCENSION = 40.589;
static const double SATURN_DECLINATION = 83.537;
static const int FULL = 1024;
static const int BORDER = 1;
static const int SIZE = FULL - 2*BORDER;
static const int ALIGNMENT_MARGIN = 192;
template<class T>
static inline T lerp(T t, T a, T b) {
    return a + t * (b-a);
}
template<class T>
static inline T cubic_delta(T t, T bdelta, T b, T c, T cdelta) {
    return lerp(t*t*(3-2*t), b, c) + 0.5*(t - t*t) * lerp(t, bdelta, -cdelta);
}
template<class T>
static inline T cubic(T t, T a, T b, T c, T d) {
    return cubic_delta(t, c-a, b, c, d-b);
}
const int Margin = 128;
const int MaxSize = 2048;
const int MarginWidth = MaxSize + 2*Margin;
const int MarginHeight = MaxSize + 2*Margin;
const int Stride = MarginWidth;
struct FullImageBuffer {
    float raw_data[MarginHeight * MarginWidth];
};
struct Image {
    float* origin_ptr;
    shared_ptr<FullImageBuffer> buf;
    int H, W;
    Image(int H, int W): buf(H && W ? make_shared<FullImageBuffer>() : nullptr), H(H), W(W) {
        _range_check(H <= MaxSize, "H <= MaxSize");
        _range_check(W <= MaxSize, "W <= MaxSize");
        origin_ptr = &buf->raw_data[Margin*Stride + Margin];
    }
    float& unsafe_at(int y, int x) const {
        return origin_ptr[y*Stride + x];
    }
    float& at(int y, int x) const {
        _range_check(-Margin <= y && y < MaxSize+Margin, "-Margin <= y && y < MaxSize+Margin");
        _range_check(-Margin <= x && x < MaxSize+Margin, "-Margin <= x && x < MaxSize+Margin");
        return unsafe_at(y, x);
    }
    float& slow_at(int y, int x) const {
        _range_check(0 <= y && y < H, "0 <= y && y < H");
        _range_check(0 <= x && x < W, "0 <= x && x < W");
        return at(y, x);
    }
    float unsafe_cubic_at(float y, float x) const {
        int i = (int)y;
        float ty = y - i;
        int j = (int)x;
        float tx = x - j;
        return cubic(ty, cubic(tx, unsafe_at(i-1,j-1), unsafe_at(i-1,j), unsafe_at(i-1,j+1), unsafe_at(i-1,j+2)), cubic(tx, unsafe_at(i,j-1), unsafe_at(i,j), unsafe_at(i,j+1), unsafe_at(i,j+2)), cubic(tx, unsafe_at(i+1,j-1), unsafe_at(i+1,j), unsafe_at(i+1,j+1), unsafe_at(i+1,j+2)), cubic(tx, unsafe_at(i+2,j-1), unsafe_at(i+2,j), unsafe_at(i+2,j+1), unsafe_at(i+2,j+2)));
    }
    Image copy() const {
        Image r(H, W);
        for (int i=0; i<r.H; i++) for (int j=0; j<r.W; j++)
            r.unsafe_at(i,j) = unsafe_at(i,j);
        return r;
    }
};
struct DynImage {
    float* origin_ptr;
    shared_ptr<vector<float> > buf;
    int H, W;
 int stride;
    DynImage(int H, int W): buf(H && W ? make_shared<vector<float> >((H + 2*Margin) * (W + 2*Margin)) : nullptr), H(H), W(W), stride(W + 2*Margin) {
        _range_check(H <= MaxSize, "H <= MaxSize");
        _range_check(W <= MaxSize, "W <= MaxSize");
        origin_ptr = &(*buf)[Margin*stride + Margin];
    }
    float& unsafe_at(int y, int x) const {
        return origin_ptr[y*stride + x];
    }
    float& slow_at_with_margin(int y, int x) const {
        _range_check(-Margin <= y && y < H+Margin, "-Margin <= y && y < H+Margin");
        _range_check(-Margin <= x && x < W+Margin, "-Margin <= x && x < W+Margin");
        return unsafe_at(y, x);
    }
    float& slow_at(int y, int x) const {
        _range_check(0 <= y && y < H, "0 <= y && y < H");
        _range_check(0 <= x && x < W, "0 <= x && x < W");
        return unsafe_at(y, x);
    }
    float unsafe_cubic_at(float y, float x) const {
        int i = (int)y;
        float ty = y - i;
        int j = (int)x;
        float tx = x - j;
        return cubic(ty, cubic(tx, unsafe_at(i-1,j-1), unsafe_at(i-1,j), unsafe_at(i-1,j+1), unsafe_at(i-1,j+2)), cubic(tx, unsafe_at(i,j-1), unsafe_at(i,j), unsafe_at(i,j+1), unsafe_at(i,j+2)), cubic(tx, unsafe_at(i+1,j-1), unsafe_at(i+1,j), unsafe_at(i+1,j+1), unsafe_at(i+1,j+2)), cubic(tx, unsafe_at(i+2,j-1), unsafe_at(i+2,j), unsafe_at(i+2,j+1), unsafe_at(i+2,j+2)));
    }
    float unsafe_bilinear_at(float y, float x) const {
        int i = (int)y;
        float ty = y - i;
        int j = (int)x;
        float tx = x - j;
        return (1-ty) * ((1-tx) * unsafe_at(i,j) + tx * unsafe_at(i,j+1))
    + ty * ((1-tx) * unsafe_at(i+1,j) + tx * unsafe_at(i+1,j+1));
    }
 Vec2 unsafe_gradient_at(int y, int x) const {
  return Vec2 { unsafe_at(y,x+1) - unsafe_at(y,x-1), unsafe_at(y+1,x) - unsafe_at(y-1,x) } * 0.5;
 }
    DynImage copy() const {
        DynImage r(H, W);
        for (int i=0; i<r.H; i++) for (int j=0; j<r.W; j++)
            r.unsafe_at(i,j) = unsafe_at(i,j);
        return r;
    }
};
struct ShotTransform {
    Vec2 cyx;
    double dy, dx, k, a, ca, sa;
    double fov;
    double N;
    double halfN;
    double delta;
    double rightAscension;
    double declination;
    double twistAngle;
    Mat3 rot_space_to_camera;
    Mat3 rot_camera_to_space;
    Mat3 rot_space_to_ring;
    Mat3 rot_ring_to_space;
    Mat3 rot_camera_to_ring;
    Mat3 rot_ring_to_camera;
    Vec3 planetRing;
public:
    ShotTransform(string instrumentID, string instrumentModeID,
            double rightAscension, double declination, double twistAngle,
            Vec3 scPlanetPositionVector) {
        this->fov = parseInstrumentID(instrumentID);
        this->N = parseInstrumentModeID(instrumentModeID);
        this->rightAscension = rightAscension;
        this->declination = declination;
        this->twistAngle = twistAngle;
        initialize();
        this->planetRing = this->rot_space_to_ring.dot(scPlanetPositionVector);
  setAdjust(0, 0, 1, 0);
    }
 void setAdjust(double dy, double dx, double k, double a) {
  this->dy = dy;
  this->dx = dx;
  this->k = k;
  this->a = a;
  ca = cos(a);
  sa = sin(a);
 }
    Vec2 yx_to_rl(double v, double u) {
  double xc = (u + dx - cyx.at(1)) * (delta*k);
  double yc = (v + dy - cyx.at(0)) * (delta*k);
        Vec3 lc = Vec3 { ca*xc - sa*yc, sa*xc + ca*yc, 1.0 };
        Vec3 lr = rot_camera_to_ring.dot(lc);
        double scale = planetRing.at(2) / lr.at(2);
        Vec3 backPlanePosition = lr * scale - planetRing;
        double x = backPlanePosition.at(0);
        double y = backPlanePosition.at(1);
        return Vec2 { sqrt(x * x + y * y), RAD_TO_DEG * atan2(y, x) };
    }
    Vec2 rl_to_yx(double radius, double longitude) {
        double longitudeInRadian = DEG_TO_RAD * longitude;
        double x = radius * cos(longitudeInRadian);
        double y = radius * sin(longitudeInRadian);
        Vec3 lr = Vec3 { x, y, 0 } + planetRing;
        Vec3 lc = rot_ring_to_camera.dot(lr);
        if (lc.at(2) <= 0) {
            throw TransformException("The camera is pointed away from the ring plane. "
                    "Backward transformation terminated.");
        }
  double xc = lc.at(0) / lc.at(2) / (delta*k);
  double yc = lc.at(1) / lc.at(2) / (delta*k);
        return Vec2 { -sa*xc + ca*yc + cyx.at(0) - dy,
                       ca*xc + sa*yc + cyx.at(1) - dx };
    }
private:
    static double parseInstrumentID(string instrumentID) {
 const double FOV_ISSNA = 0.35;
 const double FOV_ISSWA = 3.48;
        if (instrumentID == "ISSNA") {
            return FOV_ISSNA;
        } else if (instrumentID == "ISSWA") {
            return FOV_ISSWA;
        } else {
            throw TransformException("Unknown instrument id '" + instrumentID + "'.");
        }
    }
    static double parseInstrumentModeID(string instrumentModeID) {
 const double IMAGE_SIZE_FULL = 1024;
 const double IMAGE_SIZE_SUM2 = 512;
 const double IMAGE_SIZE_SUM4 = 256;
        if (instrumentModeID == "FULL") {
            return IMAGE_SIZE_FULL;
        } else if (instrumentModeID == "SUM2") {
            return IMAGE_SIZE_SUM2;
        } else if (instrumentModeID == "SUM4") {
            return IMAGE_SIZE_SUM4;
        } else {
            throw TransformException("Unknown instrument mode id '" + instrumentModeID + "'.");
        }
    }
    void initialize() {
        cyx.at(0) = cyx.at(1) = 0.5 * (SIZE-1);
        delta = tan(DEG_TO_RAD * (fov / 2.0)) / (FULL/2.0);
        double r = DEG_TO_RAD * rightAscension;
        double d = DEG_TO_RAD * declination;
        double t = DEG_TO_RAD * twistAngle;
        double sinR = sin(r);
        double cosR = cos(r);
        double sinD = sin(d);
        double cosD = cos(d);
        double sinT = sin(t);
        double cosT = cos(t);
        rot_space_to_camera = Mat3 {
            -sinR * cosT - cosR * sinD * sinT, cosR * cosT - sinR * sinD * sinT, cosD * sinT,
            sinR * sinT - cosR * sinD * cosT, -cosR * sinT - sinR * sinD * cosT, cosD * cosT,
            cosR * cosD, sinR * cosD, sinD
        };
        rot_camera_to_space = rot_space_to_camera.transpose();
        double ra = DEG_TO_RAD * SATURN_RIGHT_ASCENSION;
        double dec = DEG_TO_RAD * SATURN_DECLINATION;
        double sinRA = sin(ra);
        double cosRA = cos(ra);
        double sinDec = sin(dec);
        double cosDec = cos(dec);
        rot_space_to_ring = Mat3 {
            -sinRA, cosRA, 0,
            -cosRA * sinDec, -sinRA * sinDec, cosDec,
            cosRA * cosDec, sinRA * cosDec, sinDec
        };
        rot_ring_to_space = rot_space_to_ring.transpose();
        rot_ring_to_camera = rot_space_to_camera.dot(rot_ring_to_space);
        rot_camera_to_ring = rot_space_to_ring.dot(rot_camera_to_space);
    }
};
const double inner_encke = 133423;
const double outer_encke = 133745;
const double inner_keeler = 136485;
const double outer_keeler = 136526;
const double outer_a_ring = 136769;
const vector<float> split_radii = { inner_encke, outer_encke, inner_keeler, outer_keeler, outer_a_ring };
const double outer_roi = 136769;
const double inner_roi = 133850;
const double middle_encke = 0.5 * (inner_encke+outer_encke);
const double density_transition = 135000;
const double middle_keeler = 0.5 * (inner_keeler+outer_keeler);
int year_offset[40] = {
    0, 366, 731, 1096, 1461, 1827, 2192, 2557, 2922, 3288, 3653, 4018, 4383, 4749, 5114, 5479, 5844, 6210, 6575, 6940, 7305, 7671, 8036, 8401, 8766, 9132, 9497, 9862, 10227, 10593, 10958, 11323, 11688, 12054, 12419, 12784, 13149, 13515, 13880, 14245
};
const double YEAR = 86400 * 365.25;
double parse_timestamp(string s) {
    int y, d, hr, min;
    double sec;
    char _;
    istringstream iss(s);
    iss >> y >> _ >> d >> _ >> hr >> _ >> min >> _ >> sec;
    _range_check(y>=2000 && y<2040, "y>=2000 && y<2040");
    return (year_offset[y-2000] + d-1) * 86400.0 + hr * 3600 + min * 60 + sec;
}
template<int n>
struct SeparableKernel {
    float weight[n];
    float& operator()(int i) { return weight[n/2+i]; }
};
template<int n>
SeparableKernel<n> make_gaussian(float sigma) {
    SeparableKernel<n> r;
    for (int i=-n/2; i<=n/2; i++)
        r(i) = expf(-i*i/(2*sigma*sigma));
    float s = 0;
    for (int i=-n/2; i<=n/2; i++)
        s += r(i);
    for (int i=-n/2; i<=n/2; i++)
        r(i) /= s;
    return r;
}
template<class Image, int n>
void convolve(Image src, Image dst, Image tmp, SeparableKernel<n> ker) {
    for (int i=0; i<dst.H; i++) for (int j=0; j<dst.W; j++) {
        float s = 0;
        for (int k=-n/2; k<=n/2; k++)
            s += src.unsafe_at(i,j-k) * ker(k);
        tmp.unsafe_at(i,j) = s;
    }
    for (int i=0; i<dst.H; i++) for (int j=0; j<dst.W; j++) {
        float s = 0;
        for (int k=-n/2; k<=n/2; k++)
            s += tmp.unsafe_at(i-k,j) * ker(k);
        dst.unsafe_at(i,j) = s;
    }
}
template<int n>
void box_filter(Image img, Image tmp) {
    for (int i=0; i<img.H; i++) for (int j=0; j<img.W; j++) {
        float s = 0;
        for (int k=-n/2; k<=n/2; k++)
            s += img.unsafe_at(i,j-k);
        tmp.at(i,j) = s;
    }
    for (int i=0; i<img.H; i++) for (int j=0; j<img.W; j++) {
        float s = 0;
        for (int k=-n/2; k<=n/2; k++)
            s += tmp.unsafe_at(i-k,j);
        img.at(i,j) = s * (1.0f / (n*n));
    }
}
template<int n>
void max_filter(Image img, Image tmp) {
    for (int i=0; i<img.H; i++) for (int j=0; j<img.W; j++) {
        float s = -9e99;
        for (int k=-n/2; k<=n/2; k++)
            s = max(s, img.unsafe_at(i,j-k));
        tmp.at(i,j) = s;
    }
    for (int i=0; i<img.H; i++) for (int j=0; j<img.W; j++) {
        float s = -9e99;
        for (int k=-n/2; k<=n/2; k++)
            s = max(s, tmp.unsafe_at(i-k,j));
        img.at(i,j) = s;
    }
}
double parseDouble(string s) {
    return atof(s.c_str());
}
struct Kernel {
    int h, w;
    vector<float> data;
    float at(int i, int j) const {
        return data[i*w + j];
    }
    void convolve(const Image& src, Image& dst) const {
        for (int i=0; i<dst.H; i++) for (int j=0; j<dst.W; j++) {
            float s = 0.0f;
            for (int di=0; di<h; di++)
                for (int dj=0; dj<w; dj++)
                    s += src.unsafe_at(i-di+h/2, j-dj+w/2) * at(di, dj);
            dst.at(i,j) = s;
        }
    }
    Image convolved(const Image& src) const {
        Image dst = src.copy();
        convolve(src, dst);
        return dst;
    }
};
struct ArrayTree {
    vector<int> left;
    vector<int> right;
    vector<int> feature;
    vector<float> threshold;
    vector<float> value;
    float predict(const float* x) const {
        int i = 0;
        while (left[i]>0)
            i = x[feature[i]] < threshold[i] ? left[i] : right[i];
        return value[i];
    }
};
struct Forest {
    vector<ArrayTree> trees;
    Forest(initializer_list<ArrayTree> trees): trees(trees) {}
    float predict(const float* x) const {
        float s = 0;
        for (int i=0; i<trees.size(); i++)
            s += trees[i].predict(x);
        return s / trees.size();
    }
};
#include "pass1_field_flat4.h"
#include "pass2_all_kernels.h"
#include "pass2_forest.h"
#include "pass3_adjuster.h"
vector<Kernel> obj_kernels = all_kernels;
struct TrainLocation {
    int i,j;
    int kind;
};
struct RNG {
    unsigned int MT[624];
    int index;
 RNG(unsigned int seed = 1) {
  init(seed);
 }
    void init(unsigned int seed = 1) {
        MT[0] = seed;
        for(int i=(1);i<(624);++i) MT[i] = (1812433253UL * (MT[i-1] ^ (MT[i-1] >> 30)) + i);
        index = 0;
    }
    void generate() {
        const unsigned int MULT[] = {0, 2567483615UL};
        for (int i=0; i<227; i++) {
            unsigned int y = (MT[i] & 0x8000000UL) + (MT[i+1] & 0x7FFFFFFFUL);
            MT[i] = MT[i+397] ^ (y >> 1);
            MT[i] ^= MULT[y&1];
        }
        for(int i=(227);i<(623);++i) {
            unsigned int y = (MT[i] & 0x8000000UL) + (MT[i+1] & 0x7FFFFFFFUL);
            MT[i] = MT[i-227] ^ (y >> 1);
            MT[i] ^= MULT[y&1];
        }
        unsigned int y = (MT[623] & 0x8000000UL) + (MT[0] & 0x7FFFFFFFUL);
        MT[623] = MT[623-227] ^ (y >> 1);
        MT[623] ^= MULT[y&1];
    }
    unsigned int rand() {
        if (index == 0) {
            generate();
        }
        unsigned int y = MT[index];
        y ^= y >> 11;
        y ^= y << 7 & 2636928640UL;
        y ^= y << 15 & 4022730752UL;
        y ^= y >> 18;
        index = index == 623 ? 0 : index + 1;
        return y;
    }
    inline __attribute__ ((always_inline)) unsigned int next() {
        return rand();
    }
    inline __attribute__ ((always_inline)) int next(int x) {
        return rand() % x;
    }
    inline __attribute__ ((always_inline)) int next(int a, int b) {
        return a + (rand() % (b - a));
    }
    inline __attribute__ ((always_inline)) double nextDouble() {
        return (rand() + 0.5) * (1.0 / 4294967296.0);
    }
};
RNG gRNG(1);
struct Shot;
struct GroundTruth {
    double y, x;
    double r, l;
 double uc_r, uc_l;
 double time;
    string name;
};
struct Candidate {
    float p;
    short i,j;
    float di,dj;
    float r,l;
 float sigma_r,sigma_l;
    float blind_p;
    float forest_p;
 int region;
    Shot* shot;
    int basket;
    bool operator<(const Candidate& o) const {
        return p > o.p;
    }
    int sqr_dist(const Candidate& o) const {
        return sqr(i-o.i) + sqr(j-o.j);
    }
};
DynImage downsample(DynImage img, float sigma) {
 const int width = 5;
 SeparableKernel<width> gauss_kernel = make_gaussian<width>(sigma * sqrtf(3));
 DynImage tmp = img.copy();
 DynImage blur = img.copy();
 for (int w=0; w<width/2; w++) {
        for (int j=0; j<img.W; j++) {
            img.unsafe_at(-1-w,j) = img.unsafe_at(0,j);
            img.unsafe_at(img.H+w,j) = img.unsafe_at(img.H-1,j);
        }
        for (int i=0; i<img.H; i++) {
            img.unsafe_at(i,-1-w) = img.unsafe_at(i,0);
            img.unsafe_at(i,img.W+w) = img.unsafe_at(i,img.W-1);
        }
 }
 convolve(img, blur, tmp, gauss_kernel);
 DynImage lo(blur.H/2, blur.W/2);
 for (int i=0; i<lo.H; i++) for (int j=0; j<lo.W; j++)
  lo.unsafe_at(i,j) = blur.unsafe_at(2*i, 2*j);
 return lo;
}
const float align_sigma = 0.5;
struct ImageAligner {
 DynImage obs_gray;
 DynImage obs_bw;
 DynImage ideal_bw;
 DynImage r0;
 float scale;
 int margin;
 float lo, hi;
 float r1, r2;
 void initialize() {
  float r1 = 9e99, r2=-9e99;
  for (int i=0; i<r0.H; i++) for (int j=0; j<r0.W; j++) {
   r1 = min(r1, r0.unsafe_at(i,j));
   r2 = max(r2, r0.unsafe_at(i,j));
  }
  this->r1 = r1;
  this->r2 = r2;
 }
 vector<float> solve(vector<float> t0, vector<vector<float> > steps, int depth) {
  if (depth > 0) {
   ImageAligner child = { downsample(obs_gray, align_sigma), downsample(obs_bw, align_sigma), downsample(ideal_bw, align_sigma), downsample(r0, align_sigma), scale*.5, margin/2, lo, hi };
   vector<float> child_step = steps.at(0);
   child_step.at(0) *= 2;
   child_step.at(1) *= 2;
   vector<vector<float> > child_steps = { child_step };
   for (int i=0; i<steps.size(); i++)
    child_steps.push_back(steps[i]);
   t0 = child.solve(t0, child_steps, depth-1);
  }
  if (steps.at(0).at(0) == .25)
   return t0;
  initialize();
  float err0 = err(t0);
  for (vector<float> step : steps) {
   bool stop = false;
   while (!stop) {
    stop = true;
    vector<float> best_t = t0;
    float best_err = err0;
    for (int i=0; i<step.size(); i++) {
     for (int sign = -1; sign <= 1; sign += 2) {
      vector<float> t = t0;
      t[i] += sign * step.at(i);
      float e = err(t);
      if (e < best_err) {
       best_t = t;
       best_err = e;
       stop = false;
      }
     }
    }
    t0 = best_t;
    err0 = best_err;
   }
  }
  return t0;
 }
 float err(vector<float> t) {
  float e = 0;
  _range_check(t.size()==4, "t.S==4");
  float dii = t[2]*cos(t[3]);
  float dij = t[2]*sin(t[3]);
  float dji = -dij, djj = dii;
  float i0 = margin - scale * (SIZE/2 * dii + SIZE/2 * dij - SIZE/2 - t[0]);
  float j0 = margin - scale * (SIZE/2 * dji + SIZE/2 * djj - SIZE/2 - t[1]);
  const int z = 5;
  const int zm = z*2;
  const float sigma = 0.5;
  int n_buckets = z*obs_gray.W;
  vector<Vec2> raw_bucket(n_buckets + 2*zm);
  vector<float> bucket_mean(n_buckets + 2*zm);
  if (abs(t[0]) > ALIGNMENT_MARGIN/2 || abs(t[1]) > ALIGNMENT_MARGIN/2 || abs(t[2]) - 1 >= (double)ALIGNMENT_MARGIN/SIZE) {
   cerr << "WARNING: aligner bumped against the margins" << endl;
   return 9e99;
  }
  for (int i=0; i<obs_bw.H; i++) for (int j=0; j<obs_bw.W; j++) {
   float mi = i0 + dii*i + dij*j;
   float mj = j0 + dji*i + djj*j;
   e += sqr(obs_bw.unsafe_at(i,j) - ideal_bw.unsafe_bilinear_at(mi,mj));
   int b = (int)((r0.unsafe_bilinear_at(mi,mj) - r1) * (0.9999 * n_buckets / (r2-r1)));
   _range_check(b >= 0 && b < n_buckets, "b >= 0 && b < n_buckets");
   raw_bucket[zm+b] += Vec2 { 1, obs_gray.unsafe_at(i,j) };
  }
  SeparableKernel<2*zm+1> ker = make_gaussian<2*zm+1>(z*sigma);
  for (int i=0; i<n_buckets; i++) {
   Vec2 s = Vec2 { 0, 0 };
   for(int j=(-zm);j<(zm+1);++j)
    s += raw_bucket[zm+i+j] * ker(j);
   bucket_mean[zm+i] = s.at(1) / s.at(0);
  }
  for (int i=0; i<obs_gray.H; i++) for (int j=0; j<obs_gray.W; j++) {
   float mi = i0 + dii*i + dij*j;
   float mj = j0 + dji*i + djj*j;
   int b = (int)((r0.unsafe_bilinear_at(mi,mj) - r1) * (0.9999 * n_buckets / (r2-r1)));
   _range_check(b >= 0 && b < n_buckets, "b >= 0 && b < n_buckets");
   e += sqr(obs_gray.unsafe_at(i,j) - bucket_mean[zm+b]);
  }
  e /= obs_bw.W * obs_bw.H;
  double reg = 100.0/sqr(512);
  e += reg * (sqr(t[0]) + sqr(t[1])) / sqr(50);
  e += reg * sqr(t[2]*511 - 512.5);
  e += reg * sqr(t[3]*512);
  return e;
 }
};
static vector<vector<float> > pass1_accumulator;
static vector<string> pass3_accumulator;
struct Shot {
    string sid;
    Image rawImage;
    ShotTransform transform;
    double time;
    vector<GroundTruth> groundTruth;
    bool isTraining;
    Shot(string imageId, string startTime, double declination, double rightAscension, double twistAngle, vector<double> scPlanetPositionVector, string instrumentId, string instrumentModeId, vector<string> imageGroundTruth):
        sid(imageId),
        rawImage(0,0),
        transform(instrumentId, instrumentModeId,
            rightAscension, declination, twistAngle,
            Vec3 { scPlanetPositionVector[0], scPlanetPositionVector[1],
            scPlanetPositionVector[2] }) {
        time = parse_timestamp(startTime);
        for (int i=0; i<imageGroundTruth.size(); i++) {
            vector<string> truthy = full_split(imageGroundTruth[i], ',');
            _range_check(truthy.size() == 16, "truthy.S == 16");
            groundTruth.push_back(GroundTruth {
     parseDouble(truthy[1])-1, parseDouble(truthy[2])-1,
     parseDouble(truthy[3]), parseDouble(truthy[5]),
     parseDouble(truthy[4]), parseDouble(truthy[6]),
     time,
     truthy[15]
     });
        }
        isTraining = groundTruth.size() > 0;
    }
    void setImage(vector<double> imageData) {
        Image img(SIZE, SIZE);
        for (int i=0; i<img.H; i++) for (int j=0; j<img.W; j++)
            img.at(i,j) = imageData[i*1024 + j + 1025];
        rawImage = img;
    }
    void adjust() {
  transform.dy = 0;
  transform.dx = 0;
  transform.k = 1;
        _range_check(rawImage.H==SIZE && rawImage.W==SIZE, "rawImage.H==SIZE && rawImage.W==SIZE");
  vector<int> whole_lines;
  for (int i=0; i<rawImage.H; i++) {
   int missing = 0;
   for (int j=0; j<rawImage.W; j++) {
    if (rawImage.at(i,j)==0) {
     missing++;
     if (i==0 && j==0) {
      float corner_value = 0;
      for (int s=0; s<SIZE; s++) {
       for (int i=0; i<s+1; i++)
        if (rawImage.at(i, s-i) != 0) {
         corner_value = rawImage.at(i, s-i);
         break;
        }
       if (corner_value)
        break;
      }
      if (!corner_value)
       return;
      rawImage.at(i,j) = corner_value;
     } else if (i==0) {
      rawImage.at(i,j) = rawImage.at(i,j-1);
     } else {
      rawImage.at(i,j) = rawImage.at(i-1,j);
     }
    }
   }
   if (missing==rawImage.W)
    whole_lines.push_back(i);
  }
  int H = whole_lines.size() ? max(0, whole_lines[0]-1) : SIZE;
  int W = SIZE;
  _range_check(H <= rawImage.H, "H <= rawImage.H");
  _range_check(W <= rawImage.W, "W <= rawImage.W");
  _range_check(H > 0, "H > 0");
  _range_check(W > 0, "W > 0");
  rawImage.H = H;
  rawImage.W = W;
  const int margin = ALIGNMENT_MARGIN;
        DynImage r0(H+2*margin, W+2*margin);
        for(int i=(-margin);i<(H+margin);++i)
            for(int j=(-margin);j<(W+margin);++j)
                r0.unsafe_at(margin+i,margin+j) = transform.yx_to_rl(i,j).at(0);
        float lo, hi;
        {
            vector<float> lo_v, hi_v;
            for (int i=0; i<rawImage.H; i++) for (int j=0; j<rawImage.W; j++) {
                float r = r0.unsafe_at(margin+i,margin+j);
                if ((((int)(r >= split_radii[0]) + (int)(r >= split_radii[1]) + (int)(r >= split_radii[2]) + (int)(r >= split_radii[3]) + (int)(r >= split_radii[4])) & 1))
                    lo_v.push_back(rawImage.at(i,j));
                else
                    hi_v.push_back(rawImage.at(i,j));
            }
            if (!lo_v.size() || !hi_v.size())
                return;
            lo = destructive_median(lo_v);
            hi = destructive_median(hi_v);
        }
        if (lo > hi)
            swap(lo, hi);
        DynImage obs_bw(H, W);
        DynImage obs_gray(H, W);
        for (int i=0; i<obs_bw.H; i++) for (int j=0; j<obs_bw.W; j++) {
            float x = (rawImage.at(i,j) - lo) * (1 / (hi - lo));
            obs_bw.unsafe_at(i,j) = max(0.0f, min(1.0f, x*3 - 1));
   const float overshoot = 0.25f;
            obs_gray.unsafe_at(i,j) = max(0.0f-overshoot, min(1.0f+overshoot, x));
        }
        DynImage ideal_bw(H+2*margin, W+2*margin);
  float dr = r0.unsafe_gradient_at(margin+H/2, margin+W/2).norm();
  float invblur = .5/sqrt(sqr(4.0) + sqr(dr));
  float invblur2 = .5/sqrt(sqr(10.0) + sqr(dr));
        for (int i=0; i<ideal_bw.H; i++) for (int j=0; j<ideal_bw.W; j++) {
   float r = r0.unsafe_at(i,j);
   ideal_bw.unsafe_at(i,j) = 0.5 - 0.5 * (max(-1.0f, min(1.0f, (r - split_radii[0])*invblur)) - max(-1.0f, min(1.0f, (r - split_radii[1])*invblur)) + max(-1.0f, min(1.0f, (r - split_radii[2])*invblur)) - max(-1.0f, min(1.0f, (r - split_radii[3])*invblur)) + max(-1.0f, min(1.0f, (r - split_radii[4])*invblur2)));
  }
  double t_align = getTime();
  ImageAligner aligner = { obs_gray, obs_bw, ideal_bw, r0, 1.0f, margin, lo, hi };
  const float dyx = 0.25;
  vector<float> step = { dyx, dyx, dyx/512, dyx/512 };
  vector<float> adj0 = { 0, 0, 1, 0 };
  int depth = 5;
  vector<float> adj = aligner.solve(adj0, vector<vector<float> > { step }, depth);
  transform.setAdjust(adj.at(0), adj.at(1), adj.at(2), adj.at(3));
  double duration = getTime() - t_align;
  pass1_writeFlatfield(aligner);
    }
 void pass1_writeFlatfield(ImageAligner& aligner) {
  if (training_pass != 1)
   return;
  aligner.initialize();
  float r1 = aligner.r1, r2 = aligner.r2;
  const int z = 5;
  const int zm = z*2;
  const float sigma = 0.5;
  int n_buckets = z*rawImage.W;
  vector<Vec2> raw_bucket(n_buckets + 2*zm);
  vector<float> bucket_mean(n_buckets + 2*zm);
  for (int i=0; i<rawImage.H; i++) for (int j=0; j<rawImage.W; j++) {
   float r = transform.yx_to_rl(i,j).at(0);
   int b = (int)((r - r1) * (0.9999 * n_buckets / (r2-r1)));
   if (!(b >= 0 && b < n_buckets)) {
    cerr << vector<float> { r1, r, r2, i, j } << endl;
   }
   _range_check(b >= 0 && b < n_buckets, "b >= 0 && b < n_buckets");
   raw_bucket[zm+b] += Vec2 { 1, rawImage.at(i,j) };
  }
  SeparableKernel<2*zm+1> ker = make_gaussian<2*zm+1>(z*sigma);
  for (int i=0; i<n_buckets; i++) {
   Vec2 s = Vec2 { 0, 0 };
   for(int j=(-zm);j<(zm+1);++j)
    s += raw_bucket[zm+i+j] * ker(j);
   bucket_mean[zm+i] = s.at(1) / s.at(0);
  }
  vector<float> ratio(256*256);
  vector<float> weight(256*256);
  for (int i=0; i<rawImage.H; i++) for (int j=0; j<rawImage.W; j++) {
   float r = transform.yx_to_rl(i,j).at(0);
   int b = (int)((r - r1) * (0.9999 * n_buckets / (r2-r1)));
   _range_check(b >= 0 && b < n_buckets, "b >= 0 && b < n_buckets");
   int i4 = i/4, j4 = j/4;
   ratio.at(256*i4 + j4) += bucket_mean[zm+b] / rawImage.at(i,j);
   weight.at(256*i4 + j4)++;
  }
  for (int i=0; i<ratio.size(); i++)
   ratio[i] /= weight[i];
  pass1_accumulator.push_back(ratio);
 }
 static void pass1_finish() {
  if (training_pass != 1)
   return;
  vector<float> result;
  for (int i=0; i<256*256; i++) {
   vector<float> data;
   for (int j=0; j<pass1_accumulator.size(); j++) {
    float x = pass1_accumulator[j][i];
    if (x >= .9 && x <= 1.1)
     data.push_back(x);
   }
   result.push_back(destructive_median(data));
  }
  string path = "pass1_field_flat4.h";
  ofstream stream(path);
  if (!stream.good()) {
   cerr << "couldnt open " << path << endl;
   std::exit(1);
  }
  stream << "i8 field_flat4[] = {" << endl;
  for (int i=0; i<result.size(); i++) {
   int value = (int)round((result[i]-1) * 1000);
   stream << value << ",";
  }
  stream << endl;
  stream << "};" << endl;
  if (!stream.good()) {
   cerr << "couldnt write " << path << endl;
   std::exit(1);
  }
 }
 static void pass3_finish() {
  if (training_pass != 3)
   return;
  string path = "pass3_input.csv";
  ofstream stream(path);
  if (!stream.good()) {
   cerr << "couldnt open " << path << endl;
   std::exit(1);
  }
  stream << "sid,r,y,x,p0,p,i,j,di,dj,good" << endl;
  for (int i=0; i<pass3_accumulator.size(); i++)
   stream << pass3_accumulator[i] << endl;
  if (!stream.good()) {
   cerr << "couldnt write " << path << endl;
   std::exit(1);
  }
 }
 static void training_finish() {
  pass1_finish();
  pass3_finish();
 }
    vector<Candidate> process() {
  if (training_pass==1)
   return vector<Candidate>();
        if (training_pass==0 && isTraining)
            return vector<Candidate>();
  int rawH = rawImage.H;
  int rawW = rawImage.W;
  _range_check(rawH <= SIZE, "rawH <= SIZE");
  _range_check(rawW == SIZE, "rawW == SIZE");
        vector<Vec2> border_rl;
        for (int j=0; j<rawW; j++) {
            border_rl.push_back(transform.yx_to_rl(0, j));
            border_rl.push_back(transform.yx_to_rl(rawH-1, j));
        }
        for (int i=0; i<rawH; i++) {
            border_rl.push_back(transform.yx_to_rl(i, 0));
            border_rl.push_back(transform.yx_to_rl(i, rawW-1));
        }
        double r1 = 9e99, r2 = -9e99;
        double l1 = 9e99, l2 = -9e99;
        double offset_l1 = 9e99, offset_l2 = -9e99;
        for (int i=0; i<border_rl.size(); i++) {
            double r = border_rl[i].at(0);
            double l = border_rl[i].at(1);
            if (r >= inner_roi && r <= outer_roi) {
                r1 = min(r1, r);
                r2 = max(r2, r);
                l1 = min(l1, l);
                l2 = max(l2, l);
                offset_l1 = min(offset_l1, l<0 ? l+180 : l-180);
                offset_l2 = max(offset_l2, l<0 ? l+180 : l-180);
            }
        }
  if (offset_l2 - offset_l1 < l2 - l1) {
   l1 = offset_l1 + 180;
   l2 = offset_l2 + 180;
  }
        double r_scale = outer_a_ring;
        double l_scale = 0.5*(l1+l2);
        Vec2 a = transform.rl_to_yx(r_scale, l_scale);
        Vec2 b = transform.rl_to_yx(r_scale+1, l_scale);
        Vec2 c = transform.rl_to_yx(r_scale, l_scale + RAD_TO_DEG/r_scale);
        double dr = 1/((b-a).norm());
        double dln = 1/((c-a).norm());
        double dl = RAD_TO_DEG/r_scale * dln;
        int H = (int)(.5 + (r2-r1)/dr);
        int W = (int)(.5 + (l2-l1)/dl);
        if (H<10 || W<10)
            throw TransformException("too small, "+str(H)+"x"+str(W));
  if (H >= MaxSize && H < 10000)
   dr /= (double)(MaxSize-1)/H;
  if (W >= MaxSize && W < 10000)
   dln /= (double)(MaxSize-1)/W;
        dl = RAD_TO_DEG/r_scale * dln;
        H = (int)(.5 + (r2-r1)/dr);
        W = (int)(.5 + (l2-l1)/dl);
        if (H<10 || W<10)
            throw TransformException("too small, "+str(H)+"x"+str(W));
        if (H>MaxSize || W>MaxSize || H*W>2000*2000)
            throw TransformException("too big, "+str(H)+"x"+str(W));
        dr = (r2-r1) / (H-1);
        dl = (l2-l1) / (W-1);
  dln = dl / (RAD_TO_DEG/r_scale);
        Image attn(rawH, rawW);
        for (int i=0; i<attn.H; i++) for (int j=0; j<attn.W; j++)
            attn.at(i,j) = rawImage.at(i,j);
        for (int i=0; i<attn.H; i++) for (int j=0; j<attn.W; j++)
            attn.at(i,j) *= 1+.001f*field_flat4[i/4*256+j/4];
        for (int j=0; j<rawW; j++) {
            attn.at(-1,j) = attn.at(0,j);
            attn.at(rawH,j) = attn.at(rawH-1,j);
        }
        for (int i=0; i<rawH; i++) {
            attn.at(i,-1) = attn.at(i,0);
            attn.at(i,rawW) = attn.at(i,rawW-1);
        }
        for (int i=0; i<attn.H; i++) for (int j=0; j<attn.W; j++)
            attn.at(i,j) = 0.125*(attn.at(i-1,j) + 6*attn.at(i,j) + attn.at(i+1,j));
        for (int i=0; i<attn.H; i++) for (int j=0; j<attn.W; j++)
            attn.at(i,j) = 0.125*(attn.at(i,j-1) + 6*attn.at(i,j) + attn.at(i,j+1));
        Image img(H,W);
  Image y_image(img.H, img.W);
  vector<int> j1(H, INT_MAX);
  vector<int> j2(H, INT_MAX);
  const float shift = 0;
  for (int i=0; i<H; i++) {
   vector<pair<int,int> > segments;
   float j_mean = 0.5*(j1[i]+j2[i]-1);
   for (int j=0; j<W; j++) {
                Vec2 yx = transform.rl_to_yx(r1+dr*i + shift*dr*(j-j_mean), l1+dl*j);
                if (yx.at(0)>=0 && yx.at(0)<=rawH-1 && yx.at(1)>=0 && yx.at(1)<=rawW-1) {
                    img.at(i,j) = attn.unsafe_cubic_at(yx.at(0), yx.at(1));
     if (!segments.size() || segments[segments.size()-1].second != j) {
      segments.push_back(pair<int,int>(j, j+1));
     } else {
      segments[segments.size()-1].second = j+1;
     }
     y_image.at(i,j) = yx.at(0);
    } else {
                    img.at(i,j) = NAN;
    }
            }
   pair<int,int> longest_segment = pair<int,int>(0,0);
   for (int k=0; k<segments.size(); k++)
    if (segments[k].second - segments[k].first > longest_segment.second - longest_segment.first)
     longest_segment = segments[k];
   j1[i] = longest_segment.first;
   j2[i] = longest_segment.second;
  }
        vector<float> row(img.W);
        vector<float> row2(img.W);
        vector<float> bright(img.H);
        vector<float> slope(img.H);
        vector<float> slope2(img.H);
   for (int i=0; i<img.H; i++) {
    row.clear();
    for (int j=0; j<img.W; j++) {
     float x = img.at(i,j);
     if (x==x)
      row.push_back(x);
    }
    float mu = 0;
    if (row.size()) {
     std::nth_element(&row[0], &row[(row.size()-1)/2], &row[row.size()]);
     mu = 0.5 * (row[(row.size()-1)/2] + *std::min_element(&row[row.size()/2], &row[row.size()]));
    }
    for (int j=0; j<img.W; j++)
     img.at(i,j) -= mu;
    bright[i] = row.size() ? mu : NAN;
   }
  const int oversample = 5;
        vector<float> row3(img.W * oversample);
  int desired_slice_width = 200;
  int n_slices = max(1, (W+desired_slice_width/2)/desired_slice_width);
  int slice_width = (W+n_slices-1) / n_slices;
  const int iterations = 2;
  for (int it=0; it<iterations; it++) {
   for (int s=0; s<n_slices + 1; s++) {
    int j_root = s * slice_width;
    int jmin = min(W, max(0, j_root - slice_width));
    int jcenter = min(W, max(0, j_root));
    int jmax = min(W, max(0, j_root + slice_width));
    if (jmin == jmax)
     continue;
   for (int v=0; v<2; v++) {
    for (int i=0; i<img.H; i++) {
     row.clear();
     row2.clear();
     for(int j=(jmin);j<(jmax);++j) {
      float y = img.at(i,j);
      float dj = (j - jcenter) * (1.0/slice_width);
      float x = v==0 ? 1 - dj*dj*(3 - 2*abs(dj)) : (dj * sqr(1-abs(dj))) * 4/27;
      if (y==y) {
       row.push_back(y/x);
       row2.push_back(abs(x));
      }
     }
     float x_max = row2.size() ? *std::max_element(row2.begin(),row2.end()) : 1;
     if (x_max==0)
      continue;
     row3.clear();
     _range_check(row.size()==row2.size(), "row.S==row2.S");
     for (int l=0; l<row2.size(); l++) {
      int n = (int)(0.5 + oversample*row2[l]*(1.0/x_max));
      _range_check(n >= 0, "n >= 0");
      _range_check(n <= oversample, "n <= oversample");
      for (int k=0; k<n; k++)
       row3.push_back(row[l]);
     }
     float mu = destructive_median(row3);
     for(int j=(jmin);j<(jmax);++j) {
      float dj = (j - jcenter) * (1.0/slice_width);
      float x = v==0 ? 1 - dj*dj*(3 - 2*abs(dj)) : (dj * sqr(1-abs(dj))) * 4/27;
      img.at(i,j) -= x * mu;
     }
    }
   }
   }
  }
        vector<float> bright_sort(bright);
  float b0 = destructive_median(bright_sort);
        for (int i=0; i<bright.size(); i++)
            bright[i] /= b0;
        for (int i=0; i<slope.size(); i++)
            slope[i] /= b0;
        for (int i=0; i<slope2.size(); i++)
            slope2[i] /= b0;
        for (int i=0; i<img.H; i++) for (int j=0; j<img.W; j++)
            img.at(i,j) /= b0;
        vector<float> offset(rawH);
        vector<float> offset_w(rawH);
        for (int i=0; i<H; i++) for(int j=(j1[i]);j<(j2[i]);++j) {
            float x = img.at(i,j);
                double w = fast_invsqrt(sqr(1e-2f) + sqr(x));
                int k = (int)y_image.at(i,j);
                offset[k] += img.at(i,j) * w;
                offset_w[k] += w;
        }
        for (int k=0; k<rawH; k++)
            offset[k] /= offset_w[k] + 1e-9;
        for (int i=0; i<y_image.H; i++) for (int j=0; j<y_image.W; j++) {
            int k = (int)y_image.at(i,j);
            img.at(i,j) -= offset[k];
        }
  for (int i=0; i<H; i++) {
   float r = r1 + i*dr;
   const float noise_r1 = 134205;
   const float noise_r2 = 134375;
   float noise_x = max(0.0f, min(1.0f, (r - noise_r1)/(noise_r2 - noise_r1)));
   float noise_amp = 1 + 3.2 * 4*noise_x*(1-noise_x);
   float inv_noise_amp = 1 / noise_amp;
   for(int j=(j1[i]);j<(j2[i]);++j) {
    img.at(i,j) *= inv_noise_amp;
   }
  }
        for (int i=0; i<img.H; i++) for (int j=0; j<img.W; j++) {
            float x = img.at(i,j);
            if (!(x==x))
                img.at(i,j) = 0;
        }
        cerr << "forest" << endl;
        vector<float> feat(all_kernels.size());
        Image result(img.H, img.W);
        for (int i=0; i<H; i++) for(int j=(j1[i]);j<(j2[i]);++j) {
            for (int k=0; k<obj_kernels.size(); k++) {
                const Kernel& kernel = obj_kernels[k];
                _range_check(kernel.h==5, "kernel.h==5");
                _range_check(kernel.w==11, "kernel.w==11");
                float s = 0;
                for (int di=0; di<kernel.h; di++)
                    for (int dj=0; dj<kernel.w; dj++)
                        s += img.unsafe_at(i-di+kernel.h/2, j-dj+kernel.w/2) * kernel.at(di, dj);
                feat[k] = s;
            }
            result.at(i,j) = forest.predict(&feat[0]);
        }
        cerr << "write" << endl;
  const double p_min = .005;
        const int min_dist_emit = 30;
        const int max_candidates = 100;
        const int B = 8;
        vector<Candidate> candidates;
        for (int i=0; i<result.H/B; i++) {
            for (int j=0; j<result.W/B; j++) {
                Candidate best = Candidate { -1, 0, 0 };
                for (int di=0; di<B; di++)
                    for (int dj=0; dj<B; dj++) {
                        float p = result.at(i*B+di, j*B+dj);
                        if (p==p) {
                            best = min(best, Candidate { p>.5 ? p : 0, i*B+di, j*B+dj });
                        }
                    }
                if (best.p > p_min) {
                    candidates.push_back(best);
                }
            }
        }
        sort(candidates.begin(),candidates.end());
        vector<Candidate> best_candidates;
        Image filled(result.H, result.W);
        for (int i=0; i<candidates.size(); i++) {
            if (filled.at(candidates[i].i, candidates[i].j))
                continue;
            bool ok = true;
            for (int j=0; j<best_candidates.size(); j++)
                if (best_candidates[j].sqr_dist(candidates[i]) < sqr(min_dist_emit)) {
                    ok = false;
                    break;
                }
            if (!ok)
                continue;
            Candidate& candidate = candidates[i];
            {
                pair<int,int> init = { candidate.i, candidate.j };
                filled.at(init.first, init.second) = 1;
                vector<pair<int,int> > frontier = { init };
                int n = 0;
                Vec2 s = Vec2 { 0, 0 };
                Vec2 s2 = Vec2 { 0, 0 };
                while (!frontier.empty()) {
                    pair<int,int> x = frontier.back();
                    frontier.pop_back();
                    int i = x.first;
                    int j = x.second;
                    s = s + Vec2 { i, j };
                    s2 = s2 + Vec2 { i*i, j*j };
                    n += 1;
                    const int di[4] = { -1, 1, 0, 0 };
                    const int dj[4] = { 0, 0, -1, 1 };
                    for (int k=0; k<4; k++) {
                        if (!filled.at(i+di[k], j+dj[k]) && result.at(i+di[k], j+dj[k]) > .2) {
                            filled.at(i+di[k], j+dj[k]) = 1;
                            frontier.push_back(pair<int,int> { i+di[k], j+dj[k] });
                        }
                    }
                }
                candidate.i = s.at(0) / n;
                candidate.j = s.at(1) / n;
                candidate.di = sqrt(s2.at(0) / n - sqr(s.at(0) / n));
                candidate.dj = sqrt(s2.at(1) / n - sqr(s.at(1) / n));
            }
            best_candidates.push_back(candidates[i]);
            if (best_candidates.size() >= max_candidates)
                break;
        }
        float s = 0;
        for (int i=0; i<best_candidates.size(); i++)
            s += best_candidates[i].p;
        s = max(s, 1.0f);
        if (training_pass == 3) {
            for (int i=0; i<best_candidates.size(); i++) {
    stringstream ss;
    double r = r1 + dr * best_candidates[i].i;
    double l = l1 + dl * best_candidates[i].j;
    Vec2 yx = transform.rl_to_yx(r,l);
    bool good = false;
    for (int j=0; j<groundTruth.size(); j++)
     if ((yx - Vec2 { groundTruth[j].y, groundTruth[j].x }).norm() < 10)
      good = true;
                ss << sid << "," << i << "," << yx.at(0) << "," << yx.at(1) << "," << best_candidates[i].p << "," << best_candidates[i].p/s << "," << best_candidates[i].i << "," << best_candidates[i].j << "," << best_candidates[i].di << "," << best_candidates[i].dj << "," << (int)good;
    pass3_accumulator.push_back(ss.str());
    cerr << ss.str() << endl;
            }
        }
        for (int i=0; i<best_candidates.size(); i++)
            best_candidates[i].p /= s;
        for (int k=0; k<best_candidates.size(); k++) {
            Candidate& c = best_candidates[k];
            float features[] = { c.p, c.di, c.dj, (c.di+.1) / (c.dj+.1) };
   c.forest_p = c.p;
            c.p = adjuster.predict(features);
            c.shot = this;
            c.r = r1 + c.i * dr;
            c.l = l1 + c.j * dl;
   c.sigma_r = SIGMA_R_PIXEL * dr;
   c.sigma_l = sqrt(sqr(SIGMA_L_PIXEL * dl) + sqr(SIGMA_L_PICTURE * (l2-l1)));
        }
        sort(best_candidates.begin(),best_candidates.end());
        cerr << "write" << endl;
  if (training_pass == 2) {
   const int radius1 = 5;
   const int radius2 = 11;
   const int train_exclusion_radius = 25;
   vector<TrainLocation> locations;
   int raw_features = radius1*radius2;
   int features = raw_features + 1;
   for (int k=0; k<groundTruth.size(); k++) {
    Vec2 rl = transform.yx_to_rl(groundTruth[k].y, groundTruth[k].x);
    int i0 = (int)((rl.at(0)-r1)/dr + .5);
    int j0 = (int)((fmod(rl.at(1)-l1+180, 360)-180)/dl + .5);
    if (i0>=0 && i0<img.H && j0>=0 && j0<img.W)
     locations.push_back(TrainLocation { i0, j0, 1 });
   }
   vector<TrainLocation> ground_locations = locations;
   for (int k=0; k<500; k++) {
    TrainLocation candidate;
    bool ok = false;
    while (!ok) {
     candidate = { gRNG.next(img.H), gRNG.next(img.W), 0 };
     if (candidate.j < j1[candidate.i] || candidate.j >= j2[candidate.i])
      continue;
     ok = true;
     for (int k=0; k<ground_locations.size(); k++)
      if (sqr(candidate.i - ground_locations[k].i) + sqr(candidate.j - ground_locations[k].j) < sqr(train_exclusion_radius))
       ok = false;
    }
    locations.push_back(candidate);
   }
   Image train(locations.size(), features);
   for (int k=0; k<locations.size(); k++) {
    int i0 = locations[k].i;
    int j0 = locations[k].j;
    vector<float> zone;
    for (int i=0; i<radius1; i++) for (int j=0; j<radius2; j++)
     zone.push_back(img.at(i0+i-radius1/2, j0+j-radius2/2));
    zone.push_back(locations[k].kind);
    for (int i=0; i<zone.size(); i++)
     train.at(k,i) = zone[i];
   }
   vector<float> location_status(locations.size());
   for (int k=0; k<locations.size(); k++)
    location_status[k] = locations[k].kind;
   writeImage("train_data", train);
  }
        return best_candidates;
    }
    void minimize() {
        rawImage = Image(0,0);
    }
 template<class Image>
    void writeImage(string key, Image img) {
        mkdir(((string)"processed").c_str(), 0755);
        mkdir(((string)"processed/" + key).c_str(), 0755);
        string path = (string)"processed/" + key + "/" + sid + ".f32";
        ofstream stream(path, ios::binary);
  if (!stream.good()) {
   cerr << "couldnt open " << path << endl;
   std::exit(1);
  }
        stream.put(img.W&255);
        stream.put(img.W>>8);
        stream.put(img.H&255);
        stream.put(img.H>>8);
        for (int i=0; i<img.H; i++) for (int j=0; j<img.W; j++) {
            union {
                u32 i;
                float f;
            } x;
            x.f = img.unsafe_at(i,j);
            stream.put(x.i>>8*0);
            stream.put(x.i>>8*1);
            stream.put(x.i>>8*2);
            stream.put(x.i>>8*3);
        }
    }
};
typedef Vec2 Unit;
typedef Vec2 WeightedUnit;
Unit l_to_unit(double l) {
 return Vec2 { cos(DEG_TO_RAD * l), sin(DEG_TO_RAD * l) };
}
double unit_to_l(WeightedUnit u) {
 return RAD_TO_DEG * atan2(u.at(1), u.at(0));
}
double wrap360(double l) {
 return remainder(l, 360);
}
struct GroundOrbit {
 vector<GroundTruth> ground_obs;
 double r;
 double t0;
 double a, l0;
 double t_to_l;
 double sigma_l;
 string name;
 GroundOrbit(vector<GroundTruth> ground_obs, int identifier): ground_obs(ground_obs) {
  vector<double> obs_r, obs_r_weight;
  vector<double> obs_l, obs_t;
  name = ground_obs.at(0).name;
  for (int i=0; i<ground_obs.size(); i++) {
   const GroundTruth& g = ground_obs[i];
   obs_r.push_back(g.r);
   obs_r_weight.push_back(1/sqr(g.uc_r + 0.5));
   obs_l.push_back(g.l);
   obs_t.push_back(g.time);
  }
  r = weighted_mean(obs_r, obs_r_weight);
  t0 = mean(obs_t);
  find_semimajor_axis();
 }
 void find_semimajor_axis() {
  double a = r;
  double e = set_semimajor_axis(a);
  double e0 = e;
  bool stop = false;
  int niter = 0;
  double step = 1/16.0;
  while (!stop) {
   niter += 1;
   if (niter % 20 == 0)
    step *= 2;
   stop = true;
   double f = set_semimajor_axis(a-step);
   if (f < e) {
    a = a-step;
    e = f;
    stop = false;
    continue;
   }
   f = set_semimajor_axis(a+step);
   if (f < e) {
    a = a+step;
    e = f;
    stop = false;
    continue;
   }
  }
  set_semimajor_axis(a);
  cerr << "semi-major axis: " << a << " (" << e << ") vs " << r << " (" << e0 << ")" << ", " << niter << " iterations; name: " << name << endl;
 }
 double predict_l_unwrapped(double t) const {
  return l0 + t_to_l * (t - t0);
 }
 double likelihood(const Candidate& candidate) const {
  double e_r = 0.5 * sqr(candidate.r - r) / sqr(candidate.sigma_r);
  double e_l = 0.5 * sqr(wrap360(candidate.l - predict_l_unwrapped(candidate.shot->time))) / (sqr(candidate.sigma_l) + sqr(sigma_l));
  return exp(-e_r - e_l);
 }
 double set_semimajor_axis(double a) {
  this->a = a;
  double T = 2 * PI * sqrt(a*a*a / GRAVITATIONAL_MU);
  t_to_l = 360 / T;
  l0 = 0;
  WeightedUnit u_weighted;
  for (int i=0; i<ground_obs.size(); i++) {
   const GroundTruth& g = ground_obs[i];
   u_weighted += l_to_unit(g.l - predict_l_unwrapped(g.time));
  }
  l0 = unit_to_l(u_weighted);
  vector<double> l_sqr_error;
  l_sqr_error.push_back(sqr(ORBIT_PRIOR_L_ERROR));
  for (int i=0; i<ground_obs.size(); i++) {
   const GroundTruth& g = ground_obs[i];
   l_sqr_error.push_back(max(0.0, sqr(wrap360(g.l - predict_l_unwrapped(g.time))) - sqr(g.uc_l)));
  }
  sigma_l = sqrt(mean(l_sqr_error));
  return sqr(sigma_l);
 }
};
struct Universe {
 vector<GroundOrbit> ground_orbit;
 void initialize(vector<GroundTruth> ground_truth) {
  map<string, vector<GroundTruth> > name_map;
  for (int i=0; i<ground_truth.size(); i++)
   name_map[ground_truth[i].name].push_back(ground_truth[i]);
  int identifier = 3;
  for (auto it = name_map.begin(); it != name_map.end(); ++it) {
   if (it->first.empty())
    continue;
   ground_orbit.push_back(GroundOrbit(it->second, identifier));
   identifier++;
  }
 }
 pair<int,double> best_orbit(const Candidate& candidate) const {
  int best_orbit = -1;
  double best_likelihood = -1;
  for (int k=0; k<ground_orbit.size(); k++) {
   double likelihood = ground_orbit[k].likelihood(candidate);
   if (likelihood > best_likelihood) {
    best_likelihood = likelihood;
    best_orbit = k;
   }
  }
  return pair<int,double>(best_orbit, best_likelihood);
 }
};
struct PropellerDetector
{
    int iter = 0;
    double startTime;
 vector<GroundTruth> groundTruth;
    vector<Candidate> testingCandidates;
    PropellerDetector() {
        startTime = getTime();
    }
    double relTime() {
        return getTime() - startTime;
    }
    int trainingData(vector<double> imageData, string imageId, string startTime, double declination, double rightAscension, double twistAngle, vector<double> scPlanetPositionVector, string instrumentId, string instrumentModeId, vector<string> imageGroundTruth
            ) {
  Shot* shot = 0;
        try {
            shot = new Shot(imageId, startTime, declination, rightAscension, twistAngle, scPlanetPositionVector, instrumentId, instrumentModeId, imageGroundTruth);
            shot->setImage(imageData);
            cerr << imageId << ": " << relTime() << " s" << endl;
   shot->adjust();
            shot->process();
            shot->minimize();
   for (int i=0; i<shot->groundTruth.size(); i++)
    groundTruth.push_back(shot->groundTruth[i]);
            return 0;
        } catch (const std::exception& e) {
            cerr << "caught exception in trainingData: " << e.what() << endl;
   if (shot)
    shot->minimize();
            return 0;
        }
    }
    int testingData(vector<double> imageData, string imageId, string startTime, double declination, double rightAscension, double twistAngle, vector<double> scPlanetPositionVector, string instrumentId, string instrumentModeId
            ) {
  Shot* shot = 0;
        try {
            shot = new Shot(imageId, startTime, declination, rightAscension, twistAngle, scPlanetPositionVector, instrumentId, instrumentModeId, vector<string>{});
            shot->setImage(imageData);
            cerr << imageId << ": " << relTime() << " s" << endl;
   shot->adjust();
            vector<Candidate> candidates = shot->process();
            for (int i=0; i<candidates.size(); i++)
                testingCandidates.push_back(candidates[i]);
            shot->minimize();
            return 0;
        } catch (const std::exception& e) {
            cerr << "caught exception in testingData: " << e.what() << endl;
   if (shot)
    shot->minimize();
            return 0;
        }
    }
    vector<string> getAnswer() {
  if (training_pass != 0) {
   Shot::training_finish();
   return vector<string>();
  }
  Universe universe;
  universe.initialize(groundTruth);
  for (int k=0; k<testingCandidates.size(); k++) {
   Candidate& candidate = testingCandidates[k];
   double r = candidate.r;
   candidate.region = r < middle_encke ? 1 : r < density_transition ? 2 : r < inner_keeler - 100 ? 3 : r < middle_keeler ? 0 : r < outer_keeler + 130 ? 4 : 0;
   pair<int,double> best_orbit = universe.best_orbit(candidate);
   double p_factor = P_NO_ORBIT + best_orbit.second;
   candidate.blind_p = candidate.p;
   candidate.p = candidate.blind_p * p_factor;
   if (best_orbit.second >= P_COMMON_BASKET) {
    candidate.basket = ORBIT_BASKET + best_orbit.first;
   } else {
    candidate.basket = COMMON_BASKET;
    if (candidate.region < 2)
     candidate.p /= 50;
    if (candidate.region == 3)
     candidate.p /= 3;
   }
  }
        sort(testingCandidates.begin(),testingCandidates.end());
  int non_duplicates = testingCandidates.size();
  for (int k=0; k<non_duplicates; k++) {
   Candidate candidate = testingCandidates[k];
   candidate.p *= DUPLICATE_PROBABILITY;
   testingCandidates.push_back(candidate);
  }
        sort(testingCandidates.begin(),testingCandidates.end());
        vector<string> results;
        for (int k=0; k<min(10000, (int)testingCandidates.size()); k++) {
            try {
                ostringstream oss;
                Shot* shot = testingCandidates[k].shot;
                Vec2 yx = shot->transform.rl_to_yx(testingCandidates[k].r, testingCandidates[k].l);
                oss << shot->sid << ",";
                oss << (yx.at(0)+1) << ",";
                oss << (yx.at(1)+1) << ",";
                oss << testingCandidates[k].basket;
                results.push_back(oss.str());
            } catch (const std::exception& e) {
            }
        }
        cerr << "getAnswer: " << relTime() << " s" << endl;
        return results;
    }
};
