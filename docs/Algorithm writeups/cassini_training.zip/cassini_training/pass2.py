from __future__ import print_function, division
import numpy as np
from glob import glob

from sklearn.cluster import KMeans
from sklearn.ensemble import RandomForestRegressor
from sklearn import cross_validation, metrics

def open_image(path):
    with open(path, 'rb') as f:
        w,h = np.fromstring(f.read(4), dtype=np.uint16)
        return np.fromfile(f, dtype=np.float32).reshape(h,w)

def cpp_array(name, value, agg_type='VD', naked=False, end=';'):
    naked = naked or name is None
    prelude = '%s %s = ' % (agg_type, name) if not naked else ''
    return '%s{ %s }%s' % (prelude, ', '.join(map(str, value)), end)
def cpp_tree(tree, fmt='%.3f', thresh_fmt='%.3g'):
    return 'ArrayTree { VI%s, VI%s, VI%s, VF{ %s }, VF{ %s } }' % (
        cpp_array(None, tree.children_left, end=''),
        cpp_array(None, tree.children_right, end=''),
        cpp_array(None, tree.feature, end=''),
        ', '.join(thresh_fmt%x for x in tree.threshold),
        ', '.join(fmt%x for x in tree.value))
def cpp_forest(forest):
    return 'Forest {\n    %s\n}' % ',\n    '.join(cpp_tree(est.tree_) for est in forest.estimators_)
def cpp_kernel(name, value):
    h,w = value.shape
    name = '%s = '%name if name is not None else ''
    return 'Kernel %s{ %d, %d, VF { %s } }%s' % (name, h, w, ', '.join(map(str, value.flatten())), ';' if name else ',')
def cpp_save_kernels(filename, name, kernels):
    code = []
    code.append('VC<Kernel> %s = {' % name)
    for a in kernels:
        code.append(cpp_kernel(None, a))
    code.append('};')
    #code.append(cpp_array('obj_kernels', ['obj_kernel%d'%i for i in range(n_obj)], agg_type='VVF'))
    with open('%s.h' % filename, 'w') as f:
        print('\n'.join(code), file=f)

shape = (5,11)

xy = []
for path in glob('processed/train_data/*.f32'):
    img = open_image(path)
    xy.append(img)

xy = np.concatenate(xy, axis=0)
X = xy[:,:-1]
Y = xy[:,-1]
print(X.shape, Y.shape)

cluster_void = KMeans(4)
cluster_void.fit(X[Y==0])
cluster_obj = KMeans(10, n_init=100)
cluster_obj.fit(X[Y==1])
clusters = list(cluster_obj.cluster_centers_) + list(cluster_void.cluster_centers_)
cpp_save_kernels('pass2_all_kernels', 'all_kernels', np.array(clusters).reshape((-1,) + shape))
Xfeat = np.c_[tuple(np.tensordot(X, clusters[i], axes=(-1,-1)) for i in range(len(clusters)))]
print(Xfeat.shape)

Xfeat2 = Xfeat
forest = RandomForestRegressor(n_estimators=100, max_features=4, max_leaf_nodes=30, n_jobs=2)
class_weight = np.array([ 0.00440089,  1.99559911]) * [200,1]
#fpr = pd.Series()
for train,test in list(cross_validation.KFold(len(Y), 3)) + [(slice(None),)*2]:
    forest.fit(Xfeat2[train], Y[train], class_weight[Y[train].astype(int)])
    fp = forest.predict(Xfeat2[test][Y[test]==0])
    #src = source[test][Y[test]==0]
    #for sid in set(src):
    #    fpr[sid] = fp[src==sid].mean()
    print(metrics.confusion_matrix(Y[test], np.round(forest.predict(Xfeat2[test]))))

with open('pass2_forest.h', 'w') as f:
    print('Forest forest = %s;' % cpp_forest(forest), file=f)
