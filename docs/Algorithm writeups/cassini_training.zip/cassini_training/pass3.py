from __future__ import print_function, division
import numpy as np
import pandas as pd

from sklearn.ensemble import RandomForestRegressor

def cpp_array(name, value, agg_type='VD', naked=False, end=';'):
    naked = naked or name is None
    prelude = '%s %s = ' % (agg_type, name) if not naked else ''
    return '%s{ %s }%s' % (prelude, ', '.join(map(str, value)), end)
def cpp_tree(tree, fmt='%.3f', thresh_fmt='%.3g'):
    return 'ArrayTree { VI%s, VI%s, VI%s, VF{ %s }, VF{ %s } }' % (
        cpp_array(None, tree.children_left, end=''),
        cpp_array(None, tree.children_right, end=''),
        cpp_array(None, tree.feature, end=''),
        ', '.join(thresh_fmt%x for x in tree.threshold),
        ', '.join(fmt%x for x in tree.value))
def cpp_forest(forest):
    return 'Forest {\n    %s\n}' % ',\n    '.join(cpp_tree(est.tree_) for est in forest.estimators_)

def mean_precision(p, y):
    y = y[np.argsort(-p)]
    recalled = 0
    sum_precision = 0
    for i,g in enumerate(y):
        if g:
            sum_precision += (recalled+1)/(i+1)
            recalled += 1
    return sum_precision/recalled * recall_factor

df = pd.read_csv('pass3_input.csv', index_col=0)
x = np.array(df['p di dj'.split()])
x = np.c_[x, (x[:,-2]+.1)/(x[:,-1]+.1)]
y = np.array(df['good'])
recall_factor = len(y[y==1])/345 # we must multiply by recall rate to estimate final average recall
print(x.shape, y.shape, recall_factor)

m = RandomForestRegressor(100, max_leaf_nodes=30, max_features=3, n_jobs=2)
m.fit(x,y)
print(mean_precision(m.predict(x), y))
with open('pass3_adjuster.h', 'w') as f:
    print('Forest adjuster = %s;' % cpp_forest(m), file=f)
