This archive contains:
- the source "submission.cpp" with more comments.
- a text file "description.txt", which explains the solution, with some feedback on score improvements.
- a folder "jpg" with few images to illustrate the lack of precision on radius.
- the "some_score.ods" file, which provides few score examples and comparisons.
- this "readme.txt" file.
