#define TIMERS
// NOTE: this is a modification of Psycho's solution for Phase 1

#include <bits/stdc++.h>
#include <sys/time.h>
//#include <emmintrin.h>
#define LOCAL
/// #define WITH_OPENCV

#ifdef WITH_OPENCV
#include <opencv2/opencv.hpp>
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#endif

int THREADS_NO = 1;

const int MAX_RESULTS = 10000;
const int MAX_ID = 1000;
const double CORRECT_DIST = 7.0;
/// min distance between 2 answers at 9.0 pixels (better score than 7.0 pixels)
const double MIN_DIST = 9.0;

/// Range use for prediction
const double RADIUS_RANGE_MIN = 132815 - 500;
const double RADIUS_RANGE_MAX = 136617 + 500;
/// Range use for training
const double RADIUS_RANGE_XMIN = RADIUS_RANGE_MIN - 500;
const double RADIUS_RANGE_XMAX = RADIUS_RANGE_MAX + 500;

using namespace std;

#define INLINE   inline __attribute__ ((always_inline))
#define NOINLINE __attribute__ ((noinline))

#define ALIGNED __attribute__ ((aligned(16)))

#define likely(x)   __builtin_expect(!!(x),1)
#define unlikely(x) __builtin_expect(!!(x),0)

#define SSELOAD(a)     _mm_load_si128((__m128i*)&a)
#define SSESTORE(a, b) _mm_store_si128((__m128i*)&a, b)

#define FOR(i,a,b)  for(int i=(a);i<(b);++i)
#define REP(i,a)    FOR(i,0,a)
#define ZERO(m)     memset(m,0,sizeof(m))
#define ALL(x)      x.begin(),x.end()
#define PB          push_back
#define S           size()
#define LL          long long
#define ULL         unsigned long long
#define LD          long double
#define MP          make_pair
#define X           first
#define Y           second
#define VC          vector
#define PII         pair <int, int>
#define PDD         pair <double, double>
#define VI          VC < int >
#define VVI         VC < VI >
#define VVVI        VC < VVI >
#define VPII        VC < PII >
#define VD          VC < double >
#define VVD         VC < VD >
#define VVVD        VC < VVD >
#define VS          VC < string >
#define VVS         VC < VS >
#define DB(a)       cerr << #a << ": " << (a) << endl;

template<class T> void print(VC < T > v) {cerr << "[";if (v.S) cerr << v[0];FOR(i, 1, v.S) cerr << ", " << v[i];cerr << "]" << endl;}
template<class T> string i2s(T x) {ostringstream o; o << x; return o.str();}
VS splt(string s, char c = ' ') {VS all; int p = 0, np; while (np = s.find(c, p), np >= 0) {if (np != p) all.PB(s.substr(p, np - p)); p = np + 1;} if (p < s.S) all.PB(s.substr(p)); return all;}

double getTime() {
	timeval tv;
	gettimeofday(&tv, NULL);
	return tv.tv_sec + tv.tv_usec * 1e-6;
}

#ifdef WITH_OPENCV
void show_image_with_Encke_gap(string& imageId, VD& data, VVD& radius) {
	cv::Mat gray8_image = cv::Mat::zeros( 1024, 1024, CV_8UC3);
	auto mima = minmax_element(data.begin(), data.end());
	double mi = *mima.first;
	double ma = *mima.second;
	double range = max(ma-mi, 1e-9);
	REP(i, 1024)
		REP(j, 1024) {
			int pos = i * 1024 + j;
			double d = (data[pos] - mi) / range;
			uchar g = max(0, min(255, (int)(255.5 * d) ) );
			gray8_image.at<cv::Vec3b>(i, j) = cv::Vec3b(g,g,g);
			if( abs(radius[i][j]-133590)<150.0 )
				gray8_image.at<cv::Vec3b>(i, j)[2] = 200;
		}
	string gray8_window = imageId;
	cv::imshow( gray8_window, gray8_image );
	cv::moveWindow( gray8_window, 0, 0 );	
	cv::waitKey( 0 );
	string path = imageId + "_Encke.png";
	vector<int> compression_params;
    compression_params.push_back(CV_IMWRITE_PNG_COMPRESSION);
    compression_params.push_back(0);
	cv::imwrite(path, gray8_image);
}
void show_image_with_Encke_gap(string& imageId, VVD& data, VVD& radius) {
	VD rawdata(1024*1024);
	REP(i,1024)
		memcpy(&rawdata[i*1024], &data[i][0], 1024*sizeof(double) );
	show_image_with_Encke_gap(imageId, rawdata, radius);
}
#endif

struct RNG {
    unsigned int MT[624];
    int index;
	
	RNG(int seed = 1) {
		init(seed);
	}
    
    void init(int seed = 1) {
        MT[0] = seed;
        FOR(i, 1, 624) MT[i] = (1812433253UL * (MT[i-1] ^ (MT[i-1] >> 30)) + i);
        index = 0;
    }
    
    void generate() {
        const unsigned int MULT[] = {0, 2567483615UL};
        REP(i, 227) {
            unsigned int y = (MT[i] & 0x8000000UL) + (MT[i+1] & 0x7FFFFFFFUL);
            MT[i] = MT[i+397] ^ (y >> 1);
            MT[i] ^= MULT[y&1];
        }
        FOR(i, 227, 623) {
            unsigned int y = (MT[i] & 0x8000000UL) + (MT[i+1] & 0x7FFFFFFFUL);
            MT[i] = MT[i-227] ^ (y >> 1);
            MT[i] ^= MULT[y&1];
        }
        unsigned int y = (MT[623] & 0x8000000UL) + (MT[0] & 0x7FFFFFFFUL);
        MT[623] = MT[623-227] ^ (y >> 1);
        MT[623] ^= MULT[y&1];
    }
    
    unsigned int rand() {
        if (index == 0) {
            generate();
        }
        
        unsigned int y = MT[index];
        y ^= y >> 11;
        y ^= y << 7  & 2636928640UL;
        y ^= y << 15 & 4022730752UL;
        y ^= y >> 18;
        index = index == 623 ? 0 : index + 1;
        return y;
    }
    
    INLINE int next() {
        return rand();
    }
    
    INLINE int next(int x) {
        return rand() % x;
    }
    
    INLINE int next(int a, int b) {
        return a + (rand() % (b - a));
    }
    
    INLINE double nextDouble() {
        return (rand() + 0.5) * (1.0 / 4294967296.0);
    }
};

static RNG rng;

struct TreeNode {
	int level;
	int feature;
	double value;
	double result;
	int left;
	int right;
	
	TreeNode() {
		level = -1;
		feature = -1;
		value = 0;
		result = 0;
		left = -1;
		right = -1;
	}
};

struct RandomForestConfig {
	static const int MSE = 0;
	static const int MCE = 1;
	static const int MAE = 2;
	static const int CUSTOM = 3; // Custom

	//Grouping
	int groupFeature = -1;
	VI groups = {};
	double bagSize = 1.0;

	//Tree construction
	VI randomFeatures = {5};
	VI randomPositions = {2};
	int maxNodeSize = 1;
	int maxLevel = 100;
	
	//Feature Selection
	int featuresIgnored = 0;
	VI featuresUsed = {};
	
	int threadsNo = 1;
	int treesNo = 1;
	double timeLimit = 0;
	int lossFunction = MSE;
	bool useBootstrapping = true;
	bool computeImportances = false; 
	bool computeOOB = false; //NOT IMPLEMENTED
	
	//Boosting
	bool useLineSearch = false;
	double shrinkage = 0.1;
};

class DecisionTree {
	public:
	VC<TreeNode> nodes;
	VD importances;
	
	private:
	template <class T> INLINE T customLoss(T x) {
		return sqrt(abs(x));
	}
	
	
	public:
	
	DecisionTree() { }
	
	template <class T> DecisionTree(VC<VC<T>> &features, VC<T> &results, RandomForestConfig &config, int seed) {
		RNG r(seed);
		
		if (config.computeImportances) {
			importances = VD(features[0].S);
		}
		
		VI chosenGroups(features.S);
		if (config.groupFeature == -1 && config.groups.S == 0) {
			REP(i, (int)(features.S * config.bagSize)) chosenGroups[r.next(features.S)]++;
		} else if (config.groupFeature != -1) {
			assert(config.groupFeature >= 0 && config.groupFeature < features.S);
			unordered_map<T, int> groups;
			int groupsNo = 0;
			REP(i, features.S) if (!groups.count(features[i][config.groupFeature])) {
				groups[features[i][config.groupFeature]] = groupsNo++;
			}
			VI groupSize(groupsNo);
			REP(i, (int)(groupsNo * config.bagSize)) groupSize[r.next(groupsNo)]++;
			REP(i, features.S) chosenGroups[i] = groupSize[groups[features[i][config.groupFeature]]];
		} else {
			assert(config.groups.S == features.S);
			int groupsNo = 0;
			for (int x : config.groups) groupsNo = max(groupsNo, x + 1);
			VI groupSize(groupsNo);
			REP(i, (int)(groupsNo * config.bagSize)) groupSize[r.next(groupsNo)]++;
			REP(i, features.S) chosenGroups[i] = groupSize[config.groups[i]];
		}
		
		int bagSize = 0;
		
		/// oversampling of the detected propeller cases
		REP(i, features.S) if (results[i]>0.5 && r.next(4)==0) chosenGroups[i]++;
		REP(i, features.S) if (results[i]>0.5 && r.next(4)==0) chosenGroups[i]++;
		
		REP(i, features.S) if (chosenGroups[i]) bagSize++;
		VI bag(bagSize);
		VI weight(features.S);
		
		int pos = 0;
		
		REP(i, features.S) {
			weight[i] = config.useBootstrapping ? chosenGroups[i] : min(1, chosenGroups[i]);
			if (chosenGroups[i]) bag[pos++] = i;
		}
		
		TreeNode root;
		root.level = 0;
		root.left = 0;
		root.right = pos;
		nodes.PB(root);
		
		VI stack;
		stack.PB(0);
		
		while (stack.S) {
			bool equal = true;
			
			int curNode = stack[stack.S - 1];
			stack.pop_back();
			
			int bLeft = nodes[curNode].left;
			int bRight = nodes[curNode].right;
			int bSize = bRight - bLeft;
			
			int totalWeight = 0; 
			T totalSum = 0;
			FOR(i, bLeft, bRight) {
				totalSum += results[bag[i]] * weight[bag[i]];
				totalWeight += weight[bag[i]];
			}
			
			assert(bSize > 0);
			
			FOR(i, bLeft + 1, bRight) if (results[bag[i]] != results[bag[i - 1]]) {
				equal = false;
				break;
			}
			
			if (equal || bSize <= config.maxNodeSize || nodes[curNode].level >= config.maxLevel) {
				nodes[curNode].result = totalSum / totalWeight;
				continue;
			}
			
			int bestFeature = -1;
			int bestLeft = 0;
			int bestRight = 0;
			T bestValue = 0;
			T bestLoss = 1e99;
			
			const int randomFeatures = config.randomFeatures[min(nodes[curNode].level, (int)config.randomPositions.S - 1)];
			REP(i, randomFeatures) {
			
				int featureID = config.featuresUsed.S ? config.featuresUsed[r.next(config.featuresUsed.S)] : config.featuresIgnored + r.next(features[0].S - config.featuresIgnored);
				
				T vlo, vhi;
				vlo = vhi = features[bag[bLeft]][featureID];
				FOR(j, bLeft + 1, bRight) {
					vlo = min(vlo, features[bag[j]][featureID]);
					vhi = max(vhi, features[bag[j]][featureID]);
				}
				if (vlo == vhi) continue;
				
				const int randomPositions = config.randomPositions[min(nodes[curNode].level, (int)config.randomPositions.S - 1)];
				REP(j, randomPositions) {
					T splitValue = features[bag[bLeft + r.next(bSize)]][featureID];
					if (splitValue == vlo) {
						j--;
						continue;
					}
					
					T sumLeft = 0;
					int totalLeft = 0;
					int weightLeft = 0;
					FOR(k, bLeft, bRight) {
						int p = bag[k];
						if (features[p][featureID] < splitValue) {
							sumLeft += results[p] * weight[p];
							weightLeft += weight[p];
							totalLeft++;
						}
					}
					
					T sumRight = totalSum - sumLeft;
					int weightRight = totalWeight - weightLeft;
					int totalRight = bSize - totalLeft;
					
					if (totalLeft == 0 || totalRight == 0)
						continue;
					
					T meanLeft = sumLeft / weightLeft;
					T meanRight = sumRight / weightRight;
					T loss = 0;
					
					loss = (1 - meanLeft) * (1 - meanLeft) * sumLeft + 
						meanLeft * meanLeft * (weightLeft - sumLeft) +
						(1 - meanRight) * (1 - meanRight) * sumRight +
						meanRight * meanRight * (weightRight - sumRight);					
						
					if (config.lossFunction == RandomForestConfig::MSE) {
						FOR(k, bLeft, bRight) {
							int p = bag[k];
							if (features[p][featureID] < splitValue) {
								loss += (results[p] - meanLeft)  * (results[p] - meanLeft)  * weight[p];
							} else {
								loss += (results[p] - meanRight) * (results[p] - meanRight) * weight[p];
							}
							if (loss > bestLoss) break; //OPTIONAL
						}
					} else if (config.lossFunction == RandomForestConfig::MCE) {
						FOR(k, bLeft, bRight) {
							int p = bag[k];
							if (features[p][featureID] < splitValue) {
								loss += abs(results[p] - meanLeft)  * (results[p] - meanLeft)  * (results[p] - meanLeft)  * weight[p];
							} else {
								loss += abs(results[p] - meanRight) * (results[p] - meanRight) * (results[p] - meanRight) * weight[p];
							}
							if (loss > bestLoss) break; //OPTIONAL
						}
					} else if (config.lossFunction == RandomForestConfig::MAE) {
						FOR(k, bLeft, bRight) {
							int p = bag[k];
							if (features[p][featureID] < splitValue) {
								loss += abs(results[p] - meanLeft)  * weight[p];
							} else {
								loss += abs(results[p] - meanRight) * weight[p];
							}
							if (loss > bestLoss) break; //OPTIONAL
						}
					} else if (config.lossFunction == RandomForestConfig::CUSTOM) {
						FOR(k, bLeft, bRight) {
							int p = bag[k];
							if (features[p][featureID] < splitValue) {
								loss += customLoss(results[p] - meanLeft)  * weight[p];
							} else {
								loss += customLoss(results[p] - meanRight) * weight[p];
							}
							if (loss > bestLoss) break; //OPTIONAL
						}
					}
					
					if (loss < bestLoss) {
						bestLoss = loss;
						bestValue = splitValue;
						bestFeature = featureID;
						bestLeft = totalLeft;
						bestRight = totalRight;
						if (loss == 0) goto outer;
					}
				}
			}
			outer: 
			
			if (bestLeft == 0 || bestRight == 0) {
				nodes[curNode].result = totalSum / totalWeight;
				continue;
			}
			
			if (config.computeImportances) {
				importances[bestFeature] += bRight - bLeft;
			}
			
			//~ T mean = totalSum / totalWeight;
			
			T nextValue = -1e99;
			FOR(i, bLeft, bRight) if (features[bag[i]][bestFeature] < bestValue) nextValue = max(nextValue, features[bag[i]][bestFeature]);
			
			TreeNode left;
			TreeNode right;
			
			left.level = right.level = nodes[curNode].level + 1;
			nodes[curNode].feature = bestFeature;
			nodes[curNode].value = (bestValue + nextValue) / 2.0;
			if (!(nodes[curNode].value > nextValue)) nodes[curNode].value = bestValue;
			nodes[curNode].left = nodes.S;
			nodes[curNode].right = nodes.S + 1;
			
			int bMiddle = bRight;
			FOR(i, bLeft, bMiddle) {
				if (features[bag[i]][nodes[curNode].feature] >= nodes[curNode].value) {
					swap(bag[i], bag[--bMiddle]);
					i--;
					continue;
				}
			}
			
			assert(bestLeft == bMiddle - bLeft);
			assert(bestRight == bRight - bMiddle);
			
			left.left = bLeft;
			left.right = bMiddle;
			right.left = bMiddle;
			right.right = bRight;
			
			stack.PB(nodes.S);
			stack.PB(nodes.S + 1);
			
			nodes.PB(left);
			nodes.PB(right);
			
		}
		
		nodes.shrink_to_fit();
	}
	
	template < class T > double predict(VC < T > &features) {
		TreeNode *pNode = &nodes[0];
		while (true) {
			if (pNode->feature < 0) return pNode->result;
			pNode = &nodes[features[pNode->feature] < pNode->value ? pNode->left : pNode->right];
		}
	}
	
};

RNG gRNG(1);

class TreeEnsemble {
	public:

	VC<DecisionTree> trees;
	VD importances;
	RandomForestConfig config;
	
	void clear() {
		trees.clear();
		trees.shrink_to_fit();
	}
	
	LL countTotalNodes() {
		LL rv = 0;
		REP(i, trees.S) rv += trees[i].nodes.S;
		return rv;
	}
	
	void printImportances() {
		assert(config.computeImportances);
		
		VC<pair<double, int>> vp;
		REP(i, importances.S) vp.PB(MP(importances[i], i));
		sort(vp.rbegin(), vp.rend());
		
		REP(i, importances.S) printf("#%02d: %.6lf\n", vp[i].Y, vp[i].X);
	}
	
};

class RandomForest : public TreeEnsemble {
	public:
	
	template <class T> void train(VC<VC<T>> &features, VC<T> &results, RandomForestConfig &_config, int treesMultiplier = 1) {
		double startTime = getTime();
		config = _config;
		
		int treesNo = treesMultiplier * config.treesNo;
		
		if (config.threadsNo == 1) {
			REP(i, treesNo) {
				if (config.timeLimit && getTime() - startTime > config.timeLimit) break;
				trees.PB(DecisionTree(features, results, config, gRNG.next()));
			}
		} else {
			thread *threads = new thread[config.threadsNo];
			mutex mutex;
			REP(i, config.threadsNo) 
				threads[i] = thread([&] {
					while (true) {
						mutex.lock();
						int seed = gRNG.next();
						mutex.unlock();
						auto tree = DecisionTree(features, results, config, seed);
						mutex.lock();
						if (trees.S < treesNo)
							trees.PB(tree);
						bool done = trees.S >= treesNo || ( config.timeLimit && getTime() - startTime > config.timeLimit );
						mutex.unlock();
						if (done) break;
					}
				});
			REP(i, config.threadsNo) threads[i].join();
			delete[] threads;
		}
		
		if (config.computeImportances) {
			importances = VD(features[0].S);
			for (DecisionTree tree : trees)
				REP(i, importances.S)
					importances[i] += tree.importances[i];
			double sum = 0;
			REP(i, importances.S) sum += importances[i];
			REP(i, importances.S) importances[i] /= sum;
		}
	}
	
	template <class T> double predict(VC<T> &features) {
		assert(trees.S);
	
		double sum = 0;
		REP(i, trees.S) sum += trees[i].predict(features);
		return sum / trees.S;
	}
	
	template <class T> VD predict(VC<VC<T>> &features) {
		assert(trees.S);
	
		int samplesNo = features.S;
	
		VD rv(samplesNo);
		if (config.threadsNo == 1) {
			REP(j, samplesNo) {
				REP(i, trees.S) rv[j] += trees[i].predict(features[j]);
				rv[j] /= trees.S;
			}
		} else {
			thread *threads = new thread[config.threadsNo];
			REP(i, config.threadsNo) 
				threads[i] = thread([&](int offset) {
					for (int j = offset; j < samplesNo; j += config.threadsNo) {
						REP(k, trees.S) rv[j] += trees[k].predict(features[j]);
						rv[j] /= trees.S;
					}
				}, i);
			REP(i, config.threadsNo) threads[i].join();
			delete[] threads;
		}
		return rv;
	}
	
};



class SimpleMatrix {

public:
	VD data;
	int numRows = 0;
	int numCols = 0;
	
	SimpleMatrix() { }

	SimpleMatrix(int numRows, int numCols) {
		this->numRows = numRows;
		this->numCols = numCols;
		this->data = VD(numRows * numCols);
	}

	SimpleMatrix(VVD data) {
		this->numRows = data.S;
		this->numCols = data[0].S;
		this->data = VD(numRows * numCols);

		int pos = 0;
		REP(row, numRows) REP(col, numCols) this->data[pos++] = data[row][col];
	}

	SimpleMatrix mult(SimpleMatrix &b) {
		assert(numCols == b.numRows);
		SimpleMatrix ret = SimpleMatrix(numRows, b.numCols);
		VD &dataA = data;
		VD &dataB = b.data;
		VD &dataRet = ret.data;

		for (int i = 0; i < ret.numRows; i++) {
			for (int j = 0; j < ret.numCols; j++) {
				double sum = 0;
				int idxA = i * numRows;
				int idxB = j;
				for (int k = 0; k < numCols; k++) {
					sum += dataA[idxA++] * dataB[idxB];
					idxB += b.numCols;
				}
				dataRet[i * ret.numCols + j] = sum;
			}
		}

		return ret;
	}

	SimpleMatrix plus(SimpleMatrix &b) {
		assert(numRows == b.numRows && numCols == b.numCols);
		SimpleMatrix ret = SimpleMatrix(numRows, numCols);
		REP(i, numRows * numCols) ret.data[i] = data[i] + b.data[i];
		return ret;
	}

	SimpleMatrix minus(SimpleMatrix &b) {
		assert(numRows == b.numRows && numCols == b.numCols);
		SimpleMatrix ret = SimpleMatrix(numRows, numCols);
		REP(i, numRows * numCols) ret.data[i] = data[i] - b.data[i];
		return ret;
	}

	SimpleMatrix transpose() {
		SimpleMatrix ret = SimpleMatrix(numCols, numRows);
		REP(row, numRows) REP(col, numCols) ret.data[col * numRows + row] = data[row * numCols + col];
		return ret;
	}

	SimpleMatrix scale(double scale) {
		SimpleMatrix ret = SimpleMatrix(numRows, numCols);
		REP(i, numRows * numCols) ret.data[i] = data[i] * scale;
		return ret;
	}

	int getNumRows() {
		return numRows;
	}

	int getNumCols() {
		return numCols;
	}

	double get(int i, int j) {
		return data[i * numCols + j];
	}
};

constexpr double PI = 2 * acos(0);

class Transformer {

private:
	static constexpr double SATURN_RIGHT_ASCENSION = 40.589;
	static constexpr double SATURN_DECLINATION = 83.537;
	static constexpr double FOV_ISSNA = 0.35;
	static constexpr double FOV_ISSWA = 3.48;
	static constexpr double IMAGE_SIZE_FULL = 1024;
	static constexpr double IMAGE_SIZE_SUM2 = 512;
	static constexpr double IMAGE_SIZE_SUM4 = 256;
	double fov;
	double N;
	double halfN;
	double delta;
	double rightAscension;
	double declination;
	double twistAngle;
	SimpleMatrix cMatrix;
	SimpleMatrix inverseCMatrix;
	SimpleMatrix rMatrix;
	SimpleMatrix inverseRMatrix;
	SimpleMatrix rInverseC;
	SimpleMatrix cInverseR;
	SimpleMatrix planetRing;
	VVD cachedRadiusArray;
	VVD cachedLongitudeArray;

public:

	Transformer(string instrumentID, string instrumentModeID, double rightAscension, double declination, double twistAngle, VD &scPlanetPositionVector) {
		assert(scPlanetPositionVector.S == 3);

		this->fov = parseInstrumentID(instrumentID);
		this->N = parseInstrumentModeID(instrumentModeID);
		this->rightAscension = rightAscension;
		this->declination = declination;
		this->twistAngle = twistAngle;
		initialize();
		SimpleMatrix tmp = SimpleMatrix({scPlanetPositionVector}).transpose();
		this->planetRing = rMatrix.mult(tmp);
		this->cachedRadiusArray = VVD();
		this->cachedLongitudeArray = VVD();
	}

	PDD pixelPosition2RadiusLongitude(double u, double v) {
		SimpleMatrix lc = SimpleMatrix({{(u - halfN + 0.5) * delta}, {(v - halfN + 0.5) * delta}, {1.0}});
		SimpleMatrix lr = rInverseC.mult(lc);
		double scale = planetRing.get(2, 0) / lr.get(2, 0);
		assert(!((scale * 0) != 0));
		assert(!(scale < 0));
		SimpleMatrix backPlanePosition = lr.scale(scale).minus(planetRing);
		double x = backPlanePosition.get(0, 0);
		double y = backPlanePosition.get(1, 0);
		PDD res = MP(sqrt(x * x + y * y), radian2Degree(atan2(y, x)));
		return res;
	}

	PDD pixelPosition2RadiusLongitudeUnsafe(double u, double v) {
		/// Faster function without SimpleMatrix call ...
		double lr[3]{0.0, 0.0, 0.0};
		{
			double lc[3]{(u - halfN + 0.5) * delta, (v - halfN + 0.5) * delta, 1.0};
			REP(i,3) {
				double* vi = &rInverseC.data[3*i];
				lr[i] = vi[0] * lc[0] + vi[1] * lc[1] + vi[2] * lc[2];
			}
		}
		double* pRing = &planetRing.data[0];
		double scale = pRing[2] / lr[2];
		double x = lr[0] * scale - pRing[0];
		double y = lr[1] * scale - pRing[1];
		PDD res = MP(sqrt(x * x + y * y), radian2Degree(atan2(y, x)));
		return res;
	}

	void clearCache() {
		cachedRadiusArray = VVD();
		cachedLongitudeArray = VVD();
	}

	VVD getRadiusArray(bool useCache, double offsetX, double offsetY) {
		return getRadiusOrLongitudeArray(useCache, true, offsetX, offsetY);
	}

	VVD getLongitudeArray(bool useCache, double offsetX, double offsetY) {
		return getRadiusOrLongitudeArray(useCache, false, offsetX, offsetY);
	}

	VVD getRadiusArray(bool useCache) {
		return getRadiusOrLongitudeArray(useCache, true, 0, 0);
	}

	VVD getLongitudeArray(bool useCache) {
		return getRadiusOrLongitudeArray(useCache, false, 0, 0);
	}

private:
	static double parseInstrumentID(string instrumentID) {
		if (instrumentID == "ISSNA") {
			return FOV_ISSNA;
		} else if (instrumentID == "ISSWA") {
			return FOV_ISSWA;
		} else {
			assert(false);
		}
	}

	static double parseInstrumentModeID(string instrumentModeID) {
		if (instrumentModeID == "FULL") {
			return IMAGE_SIZE_FULL;
		} else if (instrumentModeID == "SUM2") {
			return IMAGE_SIZE_SUM2;
		} else if (instrumentModeID == "SUM4") {
			return IMAGE_SIZE_SUM4;
		} else {
			assert(false);
		}
	}

	void initialize() {
		halfN = 0.5 * N;
		delta = tan(degree2Radian(fov / 2.0)) / halfN;

		double r = degree2Radian(rightAscension);
		double d = degree2Radian(declination);
		double t = degree2Radian(twistAngle);
		double sinR = sin(r);
		double cosR = cos(r);
		double sinD = sin(d);
		double cosD = cos(d);
		double sinT = sin(t);
		double cosT = cos(t);
		cMatrix = SimpleMatrix({
						{-sinR * cosT - cosR * sinD * sinT, cosR * cosT - sinR * sinD * sinT, cosD * sinT},
						{sinR * sinT - cosR * sinD * cosT, -cosR * sinT - sinR * sinD * cosT, cosD * cosT},
						{cosR * cosD, sinR * cosD, sinD}
				});
		inverseCMatrix = cMatrix.transpose();

		// Parameters for converting sky coordinate to ring coordinates
		double ra = degree2Radian(SATURN_RIGHT_ASCENSION);
		double dec = degree2Radian(SATURN_DECLINATION);
		double sinRA = sin(ra);
		double cosRA = cos(ra);
		double sinDec = sin(dec);
		double cosDec = cos(dec);
		rMatrix = SimpleMatrix({
						{-sinRA, cosRA, 0},
						{-cosRA * sinDec, -sinRA * sinDec, cosDec},
						{cosRA * cosDec, sinRA * cosDec, sinDec}
				});
		inverseRMatrix = rMatrix.transpose();

		cInverseR = cMatrix.mult(inverseRMatrix);
		rInverseC = rMatrix.mult(inverseCMatrix);
	}

	static double degree2Radian(double d) {
		return d * PI / 180.0;
	}

	static double radian2Degree(double r) {
		return r * 180.0 / PI;
	}

	VVD getRadiusOrLongitudeArray(bool useCache, bool isRadius,	double offsetX, double offsetY) {
		// Check if cache is available
		if (useCache) {
			if (isRadius && cachedRadiusArray.S) {
				return cachedRadiusArray;
			} else if (!isRadius && cachedLongitudeArray.S) {
				return cachedLongitudeArray;
			}
		} else {
			clearCache();
		}

		int n = N + 0.5;
		if (cachedRadiusArray.S == 0 || cachedLongitudeArray.S == 0) {
			cachedRadiusArray = VVD(n, VD(n));
			cachedLongitudeArray = VVD(n, VD(n));
		}
		
		for (int i = 0; i < n; i++) {
			for (int j = 0; j< n; j++) {
				PDD radiusAndLongitude = pixelPosition2RadiusLongitudeUnsafe(j + offsetX, i + offsetY);
				cachedRadiusArray[i][j] = radiusAndLongitude.X;
				cachedLongitudeArray[i][j] = radiusAndLongitude.Y;
			}
		}
		
		if (isRadius) {
			return cachedRadiusArray;
		} else {
			return cachedLongitudeArray;
		}
	}
	

public:
	int getImageSize() {
		return (int)round(N);
	}
	
};

class RingSubtractor {

private:
	static VD calculateMinMax(VVD &array) {
		double mn = array[0][0];
		double mx = mn;
		for (VD &v : array) for (double d : v) {
			mn = min(mn, d);
			mx = max(mx, d);
		}
		return {mn, mx};
	}

	static void normalize(VVD &array) {
		VD valMinMax = calculateMinMax(array);
		double range = valMinMax[1] - valMinMax[0];
		double minimum = valMinMax[0];
		if (range > 0) {
			for (VD &v : array)
				for (double &d : v) {
					d = (d - minimum) / range;
					d = max(0.0, min( 1.0, d) );
				}
		}
	}

	static void normalize(VVD &array, double graymin, double graymax) {
		/// normalize directly with the provided min and max and assume the range is > 0.
		double inv_range = 1.0 / (graymax-graymin);
		for (VD &v : array) for (double &d : v) d = (d - graymin) * inv_range;
	}

	static void elementaryScale(VVD &array, double scale) {
		for (VD &v : array) for (double &d : v) d *= scale;
	}

	static void elementaryAdd(VVD &array, double b) {
		for (VD &v : array) for (double &d : v) d += b;
	}

	VD findBestOffset(VVD &imageData, VVD &radius, VVD &longitude) {
		int imageHeight = imageData.S;
		int imageWidth = imageData[0].S;
		VVD backPlaneX = VVD(imageHeight, VD(imageWidth));
		VVD backPlaneY = VVD(imageHeight, VD(imageWidth));
		double longitudeInRadian = 0;
		
		for (int i = 0; i < imageHeight; i++) {
			for (int j = 0; j < imageWidth; j++) {
				longitudeInRadian = longitude[i][j] / 180.0 * PI;
				backPlaneX[i][j] = radius[i][j] * cos(longitudeInRadian);
				backPlaneY[i][j] = radius[i][j] * sin(longitudeInRadian);
			}
		}

		double searchWidth = 50;
		double searchLeft = -searchWidth;
		double searchRight = searchWidth;
		double searchTop = -searchWidth;
		double searchBottom = searchWidth;
		double searchStep = 2.5;
		VD minimumOffset(2);
		
		double minimumEnergy = 1e20;
		double offsetX = 0;
		double offsetY = 0;
		if (true) {
			double noTerminateBefore = 10;
			double terminateN = 20;
			double terminateGradient = 1e-8;
			double lastEnergy = -1;
			int numIteration = 0;
			offsetX = 0; 
			offsetY = 0;
			// double initialEnergy = calculateOffsetEnergy(imageData, backPlaneX, backPlaneY, 0, 0);
			while (offsetX <= searchRight && offsetX >= searchLeft && offsetY <= searchBottom && offsetY >= searchTop) {
				double energy = calculateOffsetEnergy(imageData, backPlaneX, backPlaneY, offsetX, offsetY);
				if (energy < minimumEnergy) {
					minimumOffset[0] = max(searchLeft, min(searchRight, offsetX));
					minimumOffset[1] = max(searchTop,  min(searchBottom, offsetY));
					minimumEnergy = energy;
				}
				
				if ((lastEnergy >= 0 && abs(energy - lastEnergy) < searchStep * 0.001 && numIteration > noTerminateBefore) || numIteration > terminateN)
					break;
					
				// if (lastEnergy != -1 && energy > lastEnergy) searchStep *= 0.66;

				// double energyRight = calculateOffsetEnergy(imageData, backPlaneX, backPlaneY, offsetX + searchStep, offsetY);
				// double energyBelow = calculateOffsetEnergy(imageData, backPlaneX, backPlaneY, offsetX, offsetY + searchStep);
				double energyRight = calculateOffsetEnergy(imageData, backPlaneX, backPlaneY, offsetX + 1, offsetY);
				double energyBelow = calculateOffsetEnergy(imageData, backPlaneX, backPlaneY, offsetX, offsetY + 1);
				double gradientX = energyRight - energy;
				double gradientY = energyBelow - energy;
				double gradientLen = sqrt(gradientX * gradientX + gradientY * gradientY);
				if (gradientLen < terminateGradient) break;
				
				offsetX -= searchStep * gradientX / gradientLen;
				offsetY -= searchStep * gradientY / gradientLen;

				++numIteration;
				lastEnergy = energy;
			}
			// double finalEnergy = calculateOffsetEnergy(imageData, backPlaneX, backPlaneY, offsetX, offsetY);
			// cerr << initialEnergy << ' ' << finalEnergy << ' ' << offsetX << ' ' << offsetY << endl;
		} else {
			offsetX = searchLeft;
			while (offsetX <= searchRight) {
				offsetY = searchTop;
				while (offsetY <= searchBottom) {
					double energy = calculateOffsetEnergy(imageData, backPlaneX, backPlaneY, offsetX, offsetY);
					if (energy < minimumEnergy) {
						minimumOffset[0] = offsetX;
						minimumOffset[1] = offsetY;
						minimumEnergy = energy;
					}
					offsetY += searchStep;
				}
				offsetX += searchStep;
			}
		}
		return minimumOffset;
	}

	double calculateOffsetEnergy(VVD &imageData, VVD &backPlaneX, VVD &backPlaneY, double offsetX, double offsetY) {
		int imageHeight = imageData.S;
		int imageWidth = imageData[0].S;
		double roiInf = 0.3;
		double roiSup = 1.0 - roiInf;
		int roiTop = (int)round(imageHeight * roiInf);
		int roiLeft = (int)round(imageWidth * roiInf);
		int roiBottom = (int)round(imageHeight * roiSup);
		int roiRight = (int)round(imageWidth * roiSup);
		int rangeX = roiRight - roiLeft;
		int rangeY = roiBottom - roiTop;

		// Prepare the radius in ROI area for given offset
		double valX, valY;
		VVD offsetRadius(rangeY, VD(rangeX, 0));
		for (int i = roiTop; i < roiBottom; i++) {
			for (int j = roiLeft; j < roiRight; j++) {
				valX = bilinearInterpolation(backPlaneX, j + offsetX, i + offsetY);
				valY = bilinearInterpolation(backPlaneY, j + offsetX, i + offsetY);
				offsetRadius[i-roiTop][j-roiLeft] = sqrt(valX * valX+valY * valY);
			}
		}

		// Calculate variance in each bin
		int numBins = (int)ceil(sqrt(rangeX * rangeX + rangeY * rangeY));
		VD valMinMax = calculateMinMax(offsetRadius);
		VD sum(numBins);
		VD sumSquare(numBins);
		VD hist(numBins);
		double radiusRange = valMinMax[1] - valMinMax[0];
		if (radiusRange <= 0) return -1.0;
		
		if (numBins <= 1) return -1.0;
		
		double binWidth = radiusRange / (numBins - 1);
		int idx = 0;
		double pixelVal = 0;
		for (int i = 0; i < rangeY; i++) {
			for (int j = 0; j < rangeX; j++) {
				idx = (int)round((offsetRadius[i][j] - valMinMax[0]) / binWidth);
				hist[idx] += 1.0;
				pixelVal = imageData[i + roiTop][j + roiLeft];
				sum[idx] += pixelVal;
				sumSquare[idx] += pixelVal * pixelVal;
			}
		}

		double energy = 0;
		for (int i = 0; i < numBins; i++) {
			if (hist[i] > 0) {
				energy += max(sumSquare[i] - sum[i] * sum[i] / hist[i], 0.0);
			}
		}

		return energy;
	}

	static double bilinearInterpolation(VVD &array, double x, double y) {
		int floorX = (int)floor(x);
		int floorY = (int)floor(y);
		double u = x - floorX;
		double v = y - floorY;
		return array[floorY][floorX] * (1 - v) * (1 - u) + array[floorY][floorX + 1] * (1 - v) * u + 
		       array[floorY + 1][floorX] * v * (1 - u) + array[floorY + 1][floorX + 1] * v * u;
	}

	static VVD subtract(VVD &imageData, Transformer &transformer, VD &optimizedOffset) {
		VVD radius = transformer.getRadiusArray(false, optimizedOffset[0], optimizedOffset[1]);

		VD radiusMinMax = calculateMinMax(radius);
		assert(radiusMinMax[0] < radiusMinMax[1]);
		//throw new TransformException("Expect the backplane rings' radiuses have positive range");
		
		VD binsAverage = calculateBinsAverage(radiusMinMax[0], radiusMinMax[1],	imageData, radius);
		return subtractByBins(radiusMinMax[0], radiusMinMax[1],	binsAverage, imageData, radius);
	}

	static VD calculateBinsAverage(double minimum, double maximum, VVD &imageData, VVD &radius) {
		int numBins = (int)ceil(sqrt(2.0) * imageData.S);
		VD average(numBins);
		VD hist(numBins);
		double radiusRange = maximum - minimum;
		double binWidth = radiusRange / (numBins - 1);
		int idx = 0;

		for (int i = 0; i < imageData.S; i++) {
			for (int j = 0; j < imageData[i].S; j++) {
				idx = (int)round((radius[i][j] - minimum) / binWidth);
				hist[idx] += 1.0;
				average[idx] += imageData[i][j];
			}
		}

		for (int i = 0; i < numBins; i++) {
			if (hist[i] > 0) {
				average[i] /= hist[i];
			}
		}
		return average;
	}

	static VVD subtractByBins(double minimum, double maximum, VD &binsAverage, VVD &imageData, VVD &radius) {
		// VVD subtractedImage = imageData.clone();
		VVD subtractedImage(ALL(imageData)); //not sure if it works

		double radiusRange = maximum - minimum;
		int numBins = binsAverage.S;
		double binWidth = radiusRange / (numBins - 1);
		int idx = 0;

		for (int i = 0; i < imageData.S; i++) {
			for (int j = 0; j < imageData[i].S; j++) {
				idx = (int)round((radius[i][j] - minimum) / binWidth);
				subtractedImage[i][j] -= binsAverage[idx];
			}
		}

		return subtractedImage;
	}

public:
	VVD subtractRings(VD& rawData, VVD &imageData, Transformer &transformer) {
		/// rawData is the same data as imageData but pack in a vector (instead of vector of vector)
		/// it will allow to skip some computation during the normalization

		/// compute min and max pixel value on rawData
		sort(rawData.begin(), rawData.end());
		double grayMin = rawData[0];
		double grayMax = rawData[rawData.S-1];
		double grayRange = grayMax - grayMin;
		if (grayRange <= 0) {
			double grayMin = rawData[0];
			double grayMax = rawData[rawData.S-1];
			grayRange = grayMax - grayMin;
		}
		if (grayRange <= 0) return VVD(0);
		/// use the min/max to normalize image
		normalize(imageData, grayMin, grayMax);
		
		int transformerImageSize = transformer.getImageSize();
		if (imageData.S <= 0 || imageData.S != transformerImageSize || imageData[0].S != transformerImageSize)
			return VVD(0);
		
		VVD radius = transformer.getRadiusArray(false);
		VVD longitude = transformer.getLongitudeArray(true);

		VD optimizedOffset = findBestOffset(imageData, radius, longitude);
		//~ VD optimizedOffset = {0, 0};
		/// note that within the substact function the transformer cached radius and longitude are updated with optimizedOffset
		VVD subtractedImage = subtract(imageData, transformer, optimizedOffset);
		elementaryScale(subtractedImage, grayRange);

		return subtractedImage;
	}
};


double timePassed = 0;

VVD medianFilter(VVD &img, int size, int step) {
	/// modified medianFilter: compute the value on few pixel and then other values< with interpolation
	/// only take step that are divisor of (image size - 1), i.e for 1024-1 = 1023 = 3 * 11 * 31
	/// step can be 3, 11 , 31, 33, 93, ...	
	assert( (1023%step)==0 );
	VVD rv(1024, VD(1024, 0));

	/// temporaty data to store all value for the frame around the pixel
	/// so minimum size should be (2*size+1)^2
	double data[2048];
	
	for(int y=0; y<1024; y+=step) for(int x=0; x<1024; x+=step) {
		int no = 0;
		FOR(dy, -size, +size + 1) FOR(dx, -size, +size + 1) {
			int ny = y + dy;
			int nx = x + dx;
			if (ny >= 0 && ny < 1024 && nx >= 0 && nx < 1024)
				data[no++] = img[nx][ny];
		}
		nth_element(data, data + no / 2, data + no);
		rv[x][y] = data[no/2];
	}
	/// linear interpolation on the border
	for(int x=1; x<1023; x++)
		if(x%step) {
			int x0 = (x/step) * step;
			int x1 = x0 + step;
			rv[x][0] = (rv[x0][0] * (x1-x) + rv[x1][0] * (x-x0))/(double)step;
			rv[x][1023] = (rv[x0][1023] * (x1-x) + rv[x1][1023] * (x-x0))/(double)step;
		}
	for(int y=1; y<1023; y++)
		if(y%step) {
			int y0 = (y/step) * step;
			int y1 = y0 + step;
			rv[0][y] = (rv[0][y0] * (y1-y) + rv[0][y1] * (y-y0))/(double)step;
			rv[1023][y] = (rv[1023][y0] * (y1-y) + rv[1023][y1] * (y-y0))/(double)step;
		}	
	/// bilinear interpolation
	for (int x = 1; x < 1023; x++) {
		for (int y = 1; y<1023; y++) {
			if( (x%step) || (y%step) ) {
				int x0 = (x/step) * step;
				int x1 = x0+step;
				int y0 = (y/step) * step;
				int y1 = y0+step;
				double v00 = rv[x0][x0];
				double v01 = rv[x0][y1];
				double v10 = rv[x1][y0];
				double v11 = rv[x1][y1];
				double res = v00 * (x1-x) * (y1-y) + v01 * (x1-x) * (y-y0) + v10 * (x-x0) * (y1-y) + v11 * (x-x0) * (y-y0);
				res /= step*step;
				rv[x][y] = res;
			}
		}
	}
	return rv;
}

VVD findObjects(VVD &img, double mv = 0.0, double mv2 = 0.0015) {
	VVD rv(1024, VD(1024, 0));
	REP(y, 1023) REP(x, 1023) {
		int sign = (img[y][x] > 0) + (img[y][x+1] > 0) + (img[y+1][x] > 0) + (img[y+1][x+1] > 0);
		if (sign != 0 && sign != 4) continue;
		double sum = img[y][x] + img[y][x+1] + img[y+1][x] + img[y+1][x+1];
		if (abs(sum) <= mv) continue;
		rv[y+0][x+0] = img[y+0][x+0];
		rv[y+0][x+1] = img[y+0][x+1];
		rv[y+1][x+0] = img[y+1][x+0];
		rv[y+1][x+1] = img[y+1][x+1];
	}
	
	REP(y, 1024) REP(x, 1024) if (abs(rv[y][x]) < mv2) rv[y][x] = 0;
	
	return rv;
}

int currentImageId;


void borderFix(VVD& img) {
	/// overwrite the border value with the inner neighbor value
	const int L = 1024;
	img[0][0] = img[1][1];
	img[0][L-1] = img[1][L-2];
	img[L-1][0] = img[L-2][1];
	img[L-1][L-1] = img[L-2][L-2];
	FOR(i,1,L-1) {
		img[0][i] = img[1][i];
		img[L-1][i] = img[L-2][i];
		img[i][0] = img[i][1];
		img[i][L-1] = img[i][L-2];
	}
}

VVD blur(VVD& img) {
	/// apply a blur taking into account the 8-connected neighbors
	const int L = 1024;
	VVD res(L, VD(L,0.0));
	FOR(i,1,L-1)
		FOR(j,1,L-1)
			res[i][j] = (img[i-1][j-1] + 2*img[i-1][j] + img[i-1][j+1] +
				2*img[i][j-1] + 4*img[i][j] + 2*img[i][j+1] +
				img[i+1][j-1] + 2*img[i+1][j] + img[i+1][j+1] );
	borderFix(res);
	return res;
}

void gradIndex(VVD& img, VVD& grad, VVD& harris) {
	/// compute the gradient intensity and an Harris corner score for each pixel of the grid
	const int L = 1024;
	VVD gx(L, VD(L, 0.0));
	VVD gy(L, VD(L, 0.0));
	FOR(i,1,L-1)
		FOR(j,1,L-1) {
			gx[i][j] = ( img[i+1][j-1] - img[i-1][j-1] + 2*(img[i+1][j] - img[i-1][j]) + img[i+1][j+1] - img[i-1][j+1] );		
			gy[i][j] = ( img[i-1][j+1] - img[i-1][j-1] + 2*(img[i][j+1] - img[i][j-1]) + img[i+1][j+1] - img[i+1][j-1] );
		}
	borderFix(gx);
	borderFix(gy);
	grad.assign(L, VD(L, 0.0));
	harris.assign(L, VD(L, 0.0));
	REP(i,L)
		REP(j,L) {
			double gxij = gx[i][j];
			double gyij = gy[i][j];
			double cxx = gxij * gxij;
			double cxy = gxij * gyij;
			double cyy = gyij * gyij;
			grad[i][j] = sqrt(cxx + cyy);
			harris[i][j] = cxx*cyy - cxy*cxy - 0.04*(cxx+cyy)*(cxx+cyy);
		}
}

double sumgrid(VVD& grid, int i, int j, int di, int dj) {
	/// compute the average value over a small frame
	const int L = 1024;
	int i0 = max(0, i-di);
	int j0 = max(0, j-dj);
	int i1 = min(L, i+di+1);
	int j1 = min(L, j+dj+1);
	double res = 0.0;
	FOR(i,i0,i1) FOR(j,j0,j1) res += grid[i][j];
	res /= (i1-i0)*(j1-j0);
	return res;
}

double maxgrid(VVD& grid, int i, int j, int di, int dj) {
	/// compute the maximum value over a small frame
	const int L = 1024;
	int i0 = max(0, i-di);
	int j0 = max(0, j-dj);
	int i1 = min(L, i+di+1);
	int j1 = min(L, j+dj+1);
	double res = -1.0e100;
	FOR(i,i0,i1) FOR(j,j0,j1) res = max(res, grid[i][j]);
	return res;
}

VVD generateDetections(VVD &img, string& imageId, VVD &obj, VVD &radius, VVD &longitude, double mv = 0.0015) {
	VVI vs(1024, VI(1024, 0));
	
	const int RADIUS_BAGS = 250;
	LL iid = stoll( imageId.substr(1) );
	
	borderFix(img);
	borderFix(obj);
	VVD blurimg = blur(img);
	VVD grad, harr;
	gradIndex(blurimg, grad, harr);
	
	double minRadius = 1e9;
	double maxRadius = 0;
	for (VD &v : radius) for (double d : v) {
		minRadius = min(minRadius, d);
		maxRadius = max(maxRadius, d);
	}
	
	double bagSum[RADIUS_BAGS] = {0};
	double bagSumPos[RADIUS_BAGS] = {0};
	double bagSumNeg[RADIUS_BAGS] = {0};
	int bagSumTot[RADIUS_BAGS] = {0};
	int bagSumPosTot[RADIUS_BAGS] = {0};
	int bagSumNegTot[RADIUS_BAGS] = {0};
	
	REP(y, 1024) REP(x, 1024) {
		if (radius[y][x]>RADIUS_RANGE_XMAX || radius[y][x]<RADIUS_RANGE_XMIN) continue;
		int bag = min(RADIUS_BAGS - 1.0, max(0.0, (radius[y][x] - minRadius) / (maxRadius - minRadius) * RADIUS_BAGS));
		bagSum[bag] += obj[y][x];
		bagSumTot[bag]++;
		if (obj[y][x] > 0) {
			bagSumPos[bag] += obj[y][x];
			bagSumPosTot[bag]++;
		}
	}
	
	REP(i, RADIUS_BAGS) {
		bagSumNeg[i] = bagSum[i] - bagSumPos[i];
		bagSumNegTot[i] = bagSumTot[i] - bagSumPosTot[i];
		if (bagSumTot[i]) bagSum[i] /= bagSumTot[i];
		if (bagSumPosTot[i]) bagSumPos[i] /= bagSumPosTot[i];
		if (bagSumNegTot[i]) bagSumNeg[i] /= bagSumNegTot[i];
	}
	
	VVD rv;
	
	/// Skip 2 pixel on the border
	FOR(y, 2, 1022) FOR(x, 2, 1022) {
	
		if (vs[y][x] || abs(obj[y][x]) < mv) continue;
		
		queue<int> q;
		q.push(x);
		q.push(y);
		int sign = obj[y][x] > 0;
		
		double sum = 0;
		double sum2 = 0;
		double sumx = 0;
		double sumy = 0;
		double sumrad = 0;
		double sumlon = 0;
		double minrad = 1e9;
		double maxrad = -1e9;
		double minlon = 1e9;
		double maxlon = -1e9;
		
		double sumg = 0;
		double sumh = 0;
		double maxg = -1.0e100;
		double maxh = -1.0e100;
		
		double sump = 0;
		double sump2 = 0;
		
		int tot = 0;
		while (!q.empty()) {
			int cx = q.front(); q.pop();
			int cy = q.front(); q.pop();
			if (cx < 0 || cx >= 1024 || cy < 0 || cy >= 1024 || vs[cy][cx] || abs(obj[cy][cx]) < mv || sign != (obj[cy][cx] > 0)) continue;
			vs[cy][cx] = 1;
			
			sum += obj[cy][cx];
			sum2 += obj[cy][cx] * obj[cy][cx];
			sumx += cx;
			sumy += cy;
			sumrad += radius[cy][cx];
			sumlon += longitude[cy][cx];
			minrad = min(minrad, radius[cy][cx]);
			maxrad = max(maxrad, radius[cy][cx]);
			minlon = min(minlon, longitude[cy][cx]);
			maxlon = max(maxlon, longitude[cy][cx]);
			
			sumg += grad[cy][cx];
			sumh += harr[cy][cx];
			maxg = max(maxg, grad[cy][cx]);
			maxh = max(maxh, harr[cy][cx]);
			
			sump += img[cy][cx];
			sump2 += img[cy][cx] * img[cy][cx];
			
			tot++;
			
			q.push(cx+1); q.push(cy);
			q.push(cx-1); q.push(cy);
			q.push(cx); q.push(cy+1);
			q.push(cx); q.push(cy-1);
		}
		
		if (tot > 100) continue;
		if (tot < 4) continue;
		
		sum /= tot;
		sum2 /= tot;
		sumx /= tot;
		sumy /= tot;
		sumrad /= tot;
		sumlon /= tot;
		sumg /= tot;
		sumh /= tot;
		sump /= tot;
		sump2 /= tot;
		
		int bag = min(RADIUS_BAGS - 1., max(0., (sumrad - minRadius) / (maxRadius - minRadius) * RADIUS_BAGS));
		
		if (sumrad>RADIUS_RANGE_XMAX || sumrad<RADIUS_RANGE_XMIN) continue;
		
		VD feat;
		feat.PB(currentImageId);
		feat.PB(sumx);
		feat.PB(sumy);
		feat.PB(0.0); 
		
		feat.PB(abs(sum));
		feat.PB(sum);
		feat.PB(sum2);
		
		feat.PB(sumrad);
		// feat.PB(sumlon);
		feat.PB(tot);
		
		feat.PB(bagSum[bag]);
		
		feat.PB(bagSum[bag] - sum);
		feat.PB(bagSumPos[bag]);
		feat.PB(bagSumNeg[bag]);
		feat.PB(maxrad - minrad);
		feat.PB(maxlon - minlon);
		/// extra feature, radius range variation
		feat.PB( (maxrad - minrad) / tot );
		/// variance of pixel intensity (good)
		//~ feat.PB(sum2 - sum*sum); 
		/// average gradient over a +/-5 pixel frame around center (bad)
		//~ feat.PB( sumgrid(grad, sumx, sumy, 5, 5) );
		/// average pixel intensity over a +/-5 pixel frame around center (bad)
		//~ feat.PB( sumgrid(blurimg, sumx, sumy, 5, 5) );
		/// maximum harris corner score over a +/-5 pixel frame around center (bad)
		//~ feat.PB( maxgrid(haar, sumx, sumy, 5, 5) );
		/// average gradient over pixels of detected object (good)
		//~ feat.PB(sumg);
		/// average harris corner score over pixels of detected object (untested)
		//~ feat.PB(sumh);
		/// maximum gradient over pixels of detected object (untested)
		//~ feat.PB(maxg);
		/// maximum harris corner score over pixels of detected object (untested)
		//~ feat.PB(maxh);
		/// id number of image (untested)
		//~ feat.PB(iid);		
		/// mean pixel intensity (untested)
		//~ feat.PB( sump );
		/// variance of pixel intensity (untested)	
		//~ feat.PB( sump2 );
				
		rv.PB(feat);
	}
	return rv;
}

VI createGroups(VS &ids) {
	/// Increased width of id for a group (originally at 500)
	const int MAX_DIFF = 5000;
	VI rv(ids.S, -1);
	VC<pair<LL,int>> vp;
	REP(i, ids.S) {
		string s = ids[i];
		if (s.S < 1) continue;
		s = s.substr(1);
		bool ok = true;
		for (char c : s) ok &= isdigit(c);
		if (!ok) continue;
		LL id = atoll(s.c_str());
		if (id == 0) continue;
		vp.PB(MP(id, i));
	}
	sort(ALL(vp));
	
	int curId = -1;
	REP(i, vp.S) {
		if (i == 0 || vp[i].X - vp[i-1].X > MAX_DIFF) curId++;
		rv[vp[i].Y] = curId;
	}
	for (int &x : rv) if (x == -1) x = curId++;
	return rv;
}

VI gtfx, gtfy;

/// Debugging: few aggregated time used for profiling.
double ftime = 0.0;	
double rtime = 0.0;	
double mtime = 0.0;	
double otime = 0.0;	
double dtime = 0.0;	

VVD solve(VD &imageData, string imageId, string startTime, double declination, double rightAscension, double twistAngle, VD &scPlanetPositionVector, string instrumentId, string instrumentModeId) {
	/// unused startTime
	startTime = "";
	/// init the coordinate transformation utility
	Transformer transformer(instrumentId, instrumentModeId, rightAscension, declination, twistAngle, scPlanetPositionVector);
	/// substract rings
	double xtime =  getTime();
	VVD image(1024, VD(1024, 0));
	REP(x, 1024) REP(y, 1024) image[y][x] = imageData[x + 1024 * y];
	RingSubtractor sub;
	VVD subtracted = sub.subtractRings(imageData, image, transformer);
	/// Get radius and longitude after subtractRings, so as to benefit from the optimized fit
	VVD radius = transformer.getRadiusArray(true);
	VVD longitude = transformer.getLongitudeArray(true);
	rtime += getTime() - xtime;
	
	#ifdef WITH_OPENCV
	show_image_with_Encke_gap(imageId, image, radius);
	#endif
	
	xtime =  getTime();
	/// Changes in median filter, would even be better with size=22, step=11
	VVD median = medianFilter(subtracted, 4, 3);
	//~ VVD median = medianFilter(subtracted, 22, 11);
	mtime += getTime() - xtime;
	
	xtime = getTime();
	VVD objects(1024, VD(1024));
	REP(y, 1024) REP(x, 1024) objects[y][x] = subtracted[y][x] - median[y][x];
	objects = findObjects(objects);
	otime += getTime() - xtime;
	
	xtime = getTime();
	VVD detections = generateDetections(image, imageId, objects, radius, longitude);
	dtime += getTime() - xtime;
	return detections;
}

class PropellerDetector { 
public:

VVD trainData;
VD trainResults;
VVD testData;
VS trainIds;
VS testIds;
VI trainGroupIds;
VI testGroupIds;
	
PropellerDetector() {
	currentImageId = 0;
	trainData.clear();
	trainResults.clear();
	testData.clear();
	trainIds.clear();
	testIds.clear();
}

int trainingData(VD &imageData, string imageId, string startTime, double declination, double rightAscension, double twistAngle, VD &scPlanetPositionVector, string instrumentId, string instrumentModeId, VS &imageGroundTruth) {
	double xtime = getTime();

	gtfx.clear();
	gtfy.clear();
	for (string s : imageGroundTruth) {
		VS v = splt(s, ',');
		gtfy.PB((int)round(atof(v[1].c_str())));
		gtfx.PB((int)round(atof(v[2].c_str())));
	}
	
	VVD features = solve(imageData, imageId, startTime, declination, rightAscension, twistAngle, scPlanetPositionVector, instrumentId, instrumentModeId);
	
	trainIds.PB(imageId);
	currentImageId++;
	
	REP(i, features.S) {
		int x = (int)features[i][1];
		int y = (int)features[i][2];
		
		/// Former ground truth formula
		//~ bool correct = false;
		//~ REP(j, gtfx.S) correct |= sqrt((gtfx[j] - x) * (gtfx[j] - x) + (gtfy[j] - y) * (gtfy[j] - y)) < CORRECT_DIST;
		/// New and smoother ground truth formula.
		double correct = 0.0;
		REP(j, gtfx.S) {
			double dx = gtfx[j] - x;
			double dy = gtfy[j] - y;
			double d = sqrt(dx*dx + dy*dy);
			correct = max(correct, min(1.0, (8.0-d)/5.0) );
		}
		
		features[i][3] = correct;
		trainData.PB(features[i]);
		trainResults.PB(correct);
	}
	ftime += getTime() - xtime;
	//~ cout << imageId << "," << currentImageId << "," << ftime << endl;
	return 0;
}

int testingData(VD &imageData, string imageId, string startTime, double declination, double rightAscension, double twistAngle, VD &scPlanetPositionVector, string instrumentId, string instrumentModeId) {
	double xtime = getTime();
	
	VVD features = solve(imageData, imageId, startTime, declination, rightAscension, twistAngle, scPlanetPositionVector, instrumentId, instrumentModeId);
	
	REP(i, features.S) testData.PB(features[i]);
	
	testIds.PB(imageId);
	currentImageId++;
	ftime += getTime() - xtime;
	//~ cout << imageId << "," << currentImageId << "," << ftime << endl;
	return 0;
}

VS getAnswer() {
	trainGroupIds = createGroups(trainIds);
	testGroupIds = createGroups(testIds);
	VI testGroupCnt(testGroupIds.S, 0);
	REP(i, testGroupIds.S)
		testGroupCnt[i] = count(ALL(testGroupIds), testGroupIds[i]);
	
	print(trainGroupIds);
	print(testGroupIds);

	RandomForestConfig cfg;
	cfg.featuresIgnored = 4;
	cfg.threadsNo = THREADS_NO;
	cfg.treesNo = 250;
	cfg.randomFeatures = {4};
	cfg.maxNodeSize = 10;
	
	/// Modified random forest configuration:
	cfg.treesNo = 400;
	cfg.maxNodeSize = 4;
	cfg.bagSize = 0.25;
	cfg.computeImportances = true;
	cfg.randomPositions = {4};
	

	double xtime = getTime();	
	RandomForest RF;
	RF.train(trainData, trainResults, cfg);
	print(RF.importances);
	cout << "Train time: " << getTime() - xtime << endl;
	
	xtime = getTime();
	VC<pair<double, int>> vp;
	REP(i, testData.S) vp.PB(MP( RF.predict(testData[i]),i) );
	sort(vp.rbegin(), vp.rend());
	cout << "Predict time: " << getTime() - xtime << endl;
	
	xtime = getTime();
	VI detectionsUsed[MAX_ID];
	VS rv;
	const double MIN_DIST2 = MIN_DIST * MIN_DIST;
	/// range definition for radius used in the linking formula, 500 km range
	const double RADIUS_BASE = 130250.0;
	const double RADIUS_STEP = 500.0;
	const int COMMON_GROUP = 0;
	
	REP(i, vp.S) {
		if (rv.S >= MAX_RESULTS) break;
		
		int id = vp[i].Y;
		int imageId = testData[id][0];
		int x = testData[id][1];
		int y = testData[id][2];
		
		bool ok = true;
		for (int d : detectionsUsed[imageId]) {
			double dx = (testData[d][1] - x);
			double dy = (testData[d][2] - y);
			ok &= (dx*dx + dy*dy) > MIN_DIST2;
		}
		/// keep only candidate that are in the testing radius range
		if (!ok || testData[id][7]>RADIUS_RANGE_MAX || testData[id][7]<RADIUS_RANGE_MIN) continue;
		
		detectionsUsed[imageId].PB(id);
		/// retrieve the image group and the radius range index to build the objectID
		//~ rv.PB(testIds[imageId - trainIds.S] + "," + i2s(y) + "," + i2s(x) + "," + i2s(testGroupIds[imageId - trainIds.S] + 1));
		int g = ( testGroupCnt[imageId - trainIds.S]<=1 ) ? COMMON_GROUP : 1 + testGroupIds[imageId - trainIds.S];
		g = g * 20 + (int)( (testData[id][7]-RADIUS_BASE)/RADIUS_STEP );
		rv.PB(testIds[imageId - trainIds.S] + "," + i2s(y) + "," + i2s(x) + "," + i2s(g));
	}
	cout << "Linking time: " << getTime()-xtime << endl;
	return rv;
}

};
